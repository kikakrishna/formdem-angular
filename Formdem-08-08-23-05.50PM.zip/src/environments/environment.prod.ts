export const environment = {
  production: true,
  // local
  // apiUrl: 'http://164.52.216.127:1086/api/',
  
  // client
  apiUrl: 'http://142.93.208.158:6524/api/',
};

