import { Component, OnInit, ViewChild } from '@angular/core';
import { MatPaginator } from '@angular/material/paginator';
import { AuthenticationService } from 'src/app/_Services/authentication.service';
import { Router } from '@angular/router';
import { AdminService } from 'src/app/_Services/admin.sevice';
import { ToastService } from 'ng-uikit-pro-standard';
import { first } from 'rxjs/operators';
import { MatTableDataSource } from '@angular/material/table';
import * as moment from 'moment';

export interface PeriodicElement {
  // id: number;
  jobname: string;
  author: string;
  submissiondate: string;
  jobstatus: string;
  action: string;
}

const ELEMENT_DATA: PeriodicElement[] = [
  // {id: 1, jobname: 'SP-P1-25C-75RH', author:'Maheshwari K',  submissiondate:'30-03-2023', jobstatus: 'Algorithm 2 is running', action:'' },
  // {id: 2, jobname: 'SP-P1-25C-75RH', author:'Maheshwari K',  submissiondate:'30-03-2023', jobstatus: 'Algorithm 2 is running', action:'' },
  // {id: 3, jobname: 'SP-P1-25C-75RH', author:'Maheshwari K',  submissiondate:'30-03-2023', jobstatus: 'Algorithm 2 is running', action:'' },
  // {id: 4, jobname: 'SP-P1-25C-75RH', author:'Maheshwari K',  submissiondate:'30-03-2023', jobstatus: 'Algorithm 2 is running', action:'' },
  // {id: 5, jobname: 'SP-P1-25C-75RH', author:'Maheshwari K',  submissiondate:'30-03-2023', jobstatus: 'Algorithm 2 is running', action:'' },
  // {id: 6, jobname: 'SP-P1-25C-75RH', author:'Maheshwari K',  submissiondate:'30-03-2023', jobstatus: 'Algorithm 2 is running', action:'' },
  // {id: 7, jobname: 'SP-P1-25C-75RH', author:'Maheshwari K',  submissiondate:'30-03-2023', jobstatus: 'Algorithm 2 is running', action:'' },
  // {id: 8, jobname: 'SP-P1-25C-75RH', author:'Maheshwari K',  submissiondate:'30-03-2023', jobstatus: 'Algorithm 2 is running', action:'' },

];


@Component({
  selector: 'app-projectreport',
  templateUrl: './projectreport.component.html',
  styleUrls: ['./projectreport.component.css']
})
export class ProjectreportComponent implements OnInit {

  displayedColumns: string[] = ['jobname', 'author', 'submissiondate', 'jobstatus', 'action'];
  // dataSource = ELEMENT_DATA;
  dataSource = new MatTableDataSource<any>([]);
  @ViewChild(MatPaginator) paginator: MatPaginator;
  @ViewChild('paginator', { static: false }) reportlistpaginator: MatPaginator;
  public filerpastform_pagination_show: boolean;
  // public jobstatus: any = new MatTableDataSource([]);
  public totalSize = 10;
  public pageindex = 0;
  filterData: boolean;
  firstname: string;
  lastname: string;
  projectreportlist: any;
  loading: boolean;
  nolist: boolean;
  constructor(public authenticationService: AuthenticationService, private router: Router,
    private _AdminService: AdminService, private toastrService: ToastService) {
    this.firstname = sessionStorage.getItem("firstname");
    this.lastname = sessionStorage.getItem("lastname")
  }

  ngOnInit(): void {
    this.getprojectreport()
  }
  logout() {
    this.authenticationService.logout();
    this.router.navigate(['']);
  }
  getprojectreport() {
    this.loading = true
    this._AdminService.getprojectreport(this.pageindex, this.totalSize)
      .pipe(first())
      .subscribe((res: any) => {
        if (!res.isError) {
          this.loading = false
          console.log(res);
          let array = [];
          this.totalSize = res?.responseMessage.count;
          this.projectreportlist = res?.responseMessage.list
          this.dataSource = new MatTableDataSource(array);
          this.totalSize = res?.responseMessage.count;
          console.log(this.dataSource.filteredData.length);

          if (this.projectreportlist != undefined) {
            for (let item of res?.responseMessage.list) {
              let d = new Date(item?.submissiondate);
              item.submissiondate = moment(d).format('MMMM D, YYYY');
              array.push(item);
            }
          }

          if (array.length == 0) {
            this.nolist = true;
          } else {
            this.nolist = false;

          }
          // setTimeout(() => {
          //   // this.dataSource.paginator = this.paginator
          // });
        }
        else {
          const options = { opacity: 1, timeOut: 2000, tapToDismiss: true };
          this.toastrService.warning('', res.errorMessage, options);
        }
      },
        err => {
          const options = { opacity: 1, timeOut: 2000, tapToDismiss: true };
          console.log(err);

        });
  }
  getNext(event) {
    this.loading = true;
    let array = [];
    this._AdminService.getprojectreport(event.pageIndex, event.pageSize)
      .pipe(first())
      .subscribe((res: any) => {
        console.log(res)
        if (!res.isError) {
          this.loading = false;
          this.projectreportlist = res?.responseMessage.list;
          this.dataSource = new MatTableDataSource(array);
          for (let item of res?.responseMessage.list) {
            let d = new Date(item?.submissiondate);
            item.submissiondate = moment(d).format('MMMM D, YYYY');
            array.push(item);
          }


        }
        else {
          this.loading = false;
          const options = { opacity: 1, timeOut: 2000, tapToDismiss: true };
          this.toastrService.warning('', res.errorMessage, options);
        }
      },
        err => {
          this.loading = false;
          const options = { opacity: 1, timeOut: 2000, tapToDismiss: true };
          this.toastrService.warning('', err?.error, options);
        });
  }
  jobname: any;
  data: any;
  pdfdownload(ele) {
    console.log(ele);
    this.jobname = ele.jobname.replace(/\./g, "-");
    this.loading = true
    this._AdminService.downloadpdf(ele.jobid)
      .pipe(first())
      .subscribe((res: any) => {
        if (!res.isError) {
          this.loading = false
          console.log(res);
          const newBlob = new Blob([res], { type: 'application/csv' });
          this.data = window.URL.createObjectURL(res);
          const file_path = this.data;
          const down = document.createElement('A') as HTMLAnchorElement;
          down.href = file_path;
          down.download = this.jobname
          document.body.appendChild(down);
          down.click();
          document.body.removeChild(down);

        }
        else {
          this.loading = false
          const options = { opacity: 1, timeOut: 2000, tapToDismiss: true };
          this.toastrService.warning('', res.errorMessage, options);

        }
      },
        err => {
          const options = { opacity: 1, timeOut: 2000, tapToDismiss: true };
          console.log(err);

        });
  }
}
