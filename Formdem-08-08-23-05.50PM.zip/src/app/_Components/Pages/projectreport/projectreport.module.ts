import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { RouterModule } from '@angular/router';
import { MatCardModule } from '@angular/material/card';
import { MatTableModule } from '@angular/material/table';
import { MatButtonModule } from '@angular/material/button';
import {MatSelectModule} from '@angular/material/select';
import { MatMenuModule } from '@angular/material/menu';
import { MatIconModule } from '@angular/material/icon';
import { MatPaginatorModule } from '@angular/material/paginator';
import { ProjectreportComponent } from './projectreport.component';
import { ProjectreportRoutes } from './projectreport.routes';

@NgModule({
  declarations: [ProjectreportComponent],
  imports: [
    CommonModule,
    RouterModule.forChild(ProjectreportRoutes),
    MatCardModule,
    MatTableModule,
    MatButtonModule,
    MatSelectModule,
    MatMenuModule,
    MatIconModule,
    MatPaginatorModule,

  ]
})
export class ProjectreportModule { }