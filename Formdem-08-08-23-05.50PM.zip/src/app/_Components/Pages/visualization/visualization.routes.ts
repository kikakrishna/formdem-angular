import { RouterModule } from "@angular/router";
import { VisualizationComponent } from "./visualization.component";
export const VisualizationRoutes: RouterModule [] = [
    {
        path: '',
        component: VisualizationComponent
    }
]