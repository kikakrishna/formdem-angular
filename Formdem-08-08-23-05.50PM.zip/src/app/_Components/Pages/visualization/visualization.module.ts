import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { RouterModule } from '@angular/router';
import { VisualizationComponent } from './visualization.component';
import { VisualizationRoutes } from './visualization.routes';
import { MatCardModule } from '@angular/material/card';
import { MatButtonModule } from '@angular/material/button';
import {MatSelectModule} from '@angular/material/select';
 import {MatRadioModule} from '@angular/material/radio';
 import { MatFormFieldModule } from '@angular/material/form-field';
import {  MatTableModule } from '@angular/material/table';
import { MatMenuModule } from '@angular/material/menu';
import { MatIconModule } from '@angular/material/icon';
import { ChartsModule } from 'ng2-charts';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { MatInputModule } from '@angular/material/input';

@NgModule({
  declarations: [VisualizationComponent],
  imports: [
    CommonModule,
    RouterModule.forChild(VisualizationRoutes),
    MatCardModule,
    MatButtonModule,
    MatSelectModule,
     MatRadioModule,
     MatFormFieldModule,
     MatTableModule,
     MatMenuModule,
     MatIconModule,
     ChartsModule,
     FormsModule,
     ReactiveFormsModule,
     MatInputModule,
     
  ]
  
})
export class VisualizationModule { }
