import { Component, OnInit } from '@angular/core';
import { FormBuilder, FormGroup, Validators, FormArray, AbstractControl, NgForm, FormControl, FormControlName } from '@angular/forms';
import { ChartOptions, ChartType, ChartDataSets } from 'chart.js';
import { ToastService } from 'ng-uikit-pro-standard';
import { Label, Color } from 'ng2-charts';
import { AdminService } from 'src/app/_Services/admin.sevice';
import { first, retry, take, takeUntil, map, startWith } from 'rxjs/operators';
import { MatTableDataSource } from '@angular/material/table';
import { AuthenticationService } from 'src/app/_Services/authentication.service';
import { Router } from '@angular/router';

export interface PeriodicElement {
  name: string;
  ingredient: string;
  fraction: string;
  activity: string;
}
export interface PeriodicElement2 {
  name: string;
  ingredient: string;
  fraction: string;
  activity: string;
  name2: string;
  fraction2: string;
  activity2: string;
  name3: string;
  fraction3: string;
  activity3: string;
}
// const ELEMENT_DATA: PeriodicElement[] = [
//   { ingredient: "API Maleate", name: '50', fraction: "0.2", activity: '0.86' },
//   { ingredient: "Mannitol", name: '50', fraction: "0.2", activity: '0.86' },
//   { ingredient: "Starch", name: '50', fraction: "0.2", activity: '' },
//   { ingredient: "Pre gelatinized starch", name: '50', fraction: "0.2", activity: '' },
//   { ingredient: "YY", name: '', fraction: "0.2", activity: '0.86' },
//   { ingredient: "Sodium Stearyl Fumarate", name: '', fraction: "", activity: '' },
//   { ingredient: "VV", name: '50', fraction: "0.2", activity: '' },
//   { ingredient: "XX", name: '', fraction: "0.2", activity: '' },
//   { ingredient: "NN", name: '50', fraction: "0.2", activity: '0.86' },
//   { ingredient: "Weight of Core Tablet", name: '', fraction: "", activity: '' },
// ];
// const ELEMENT_DATA1: PeriodicElement2[] = [
//   { ingredient: "API Maleate", name: '50', fraction: "0.2", activity: '0.86', name2: '50', fraction2: "0.2", activity2: '0.86', name3: '50', fraction3: "0.2", activity3: '0.86' },
//   { ingredient: "Mannitol", name: '50', fraction: "0.2", activity: '0.86', name2: '50', fraction2: "0.2", activity2: '0.86', name3: '50', fraction3: "0.2", activity3: '0.86' },
//   { ingredient: "Starch", name: '50', fraction: "0.2", activity: '', name2: '50', fraction2: "0.2", activity2: '0.86', name3: '50', fraction3: "0.2", activity3: '0.86' },
//   { ingredient: "Pre gelatinized starch", name: '50', fraction: "0.2", activity: '', name2: '50', fraction2: "0.2", activity2: '0.86', name3: '50', fraction3: "0.2", activity3: '0.86' },
//   { ingredient: "YY", name: '', fraction: "0.2", activity: '0.86', name2: '50', fraction2: "0.2", activity2: '0.86', name3: '50', fraction3: "0.2", activity3: '0.86' },
//   { ingredient: "Sodium Stearyl Fumarate", name: '', fraction: "", activity: '', name2: '', fraction2: "", activity2: '', name3: '', fraction3: "", activity3: '' },
//   { ingredient: "VV", name: '50', fraction: "0.2", activity: '', name2: '50', fraction2: "0.2", activity2: '0.86', name3: '50', fraction3: "0.2", activity3: '0.86' },
//   { ingredient: "XX", name: '', fraction: "0.2", activity: '', name2: '50', fraction2: "0.2", activity2: '0.86', name3: '50', fraction3: "0.2", activity3: '0.86' },
//   { ingredient: "NN", name: '50', fraction: "0.2", activity: '0.86', name2: '50', fraction2: "0.2", activity2: '0.86', name3: '50', fraction3: "0.2", activity3: '0.86' },
//   { ingredient: "Weight of Core Tablet", name: '', fraction: "", activity: '', name2: '', fraction2: "", activity2: '', name3: '', fraction3: "", activity3: '' },
// ];
@Component({
  selector: 'app-visualization',
  templateUrl: './visualization.component.html',
  styleUrls: ['./visualization.component.css']
})
export class VisualizationComponent implements OnInit {
  displayedColumns: string[] = ['ingredient', 'name', 'fraction', 'StabilityScore'];
  displayedColumns1: string[] = ['ingredient', 'name', 'fraction', 'activity', 'name2', 'fraction2', 'activity2', 'name3', 'fraction3', 'activity3'];
  // dataSource = ELEMENT_DATA;
  // dataSource1 = ELEMENT_DATA1;
  aftersubmitsinglejob: boolean = false;
  singlejobvisualization: boolean = true;
  listdata: boolean = false;
  JobidForm: FormGroup;
  singlejobform: FormGroup;
  singlejobid: any;
  multijobid: any;
  jobids: any = [];
  jobid = new FormControl('', [Validators.required]);
  dataSource = new MatTableDataSource<any>([]);
  jobidsId: any;
  firstname: string;
  lastname: string;
  loading: boolean;
  data: string;
  temparray: any[];
  tempparray: any[];
  headerinfotempparray: any = [];
  exam: any = [];
  firstjobform: FormGroup;
  tablejobname: any = []
  multitableview: boolean = false;
  // jsondata: any;
  radiobtnclickjson: any;
  dataa: any = []
  singlechart: FormGroup;
  selectexcipient: any;
  ChangeData(ele) {
    console.log(ele.value);
    if (ele.value == "SP") {
      this.singlejobvisualization = true
      this.singlejobform.reset();
      this.aftersubmitsinglejob = false;
      this.jobid.reset();
      this.JobidForm.reset();
    } else {
      this.JobidForm.reset()
      this.singlejobvisualization = false
      this.multitableview = false
    }

  }

  //single page  bar chart 1 ---------------------------------------------
  public barChartData = []
  public barChartLabels = [];


  // =============================

  public barChartOptions: ChartOptions = {

    responsive: true,
  };
  // public barChartLabels: Label[] = [];
  public barChartType: ChartType = 'bar';
  public barChartLegend = true;

  // public barChartData: ChartDataSets[] = [
  //   { data: [65, 59, 80, 81, 56, 55, 40], "hoverBackgroundColor": '#004090', label: 'Series A' },
  // ];
  // public barChartData: ChartDataSets[] = [
  //   // { data: [3.5, 2.5, 1.5, 0], "hoverBackgroundColor": '#EDF4FD', label: 'Series A' },
  // ];

  // public barChartColors: Color[] = [
  //   // { backgroundColor: '#004090' },

  // ]


  //single page  bar chart 2 ---------------------------------------------

  public singlebarChartOptions1: ChartOptions = {

    responsive: true,
  };
  public singlebarChartLabels = []
  // public singlebarChartLabels: Label[] = ['ARS1_SP_ARS_Test 12_25C_60RH', 'ARS1_SP_ARS_test03_25C_60RH', 'P-004_SP_Job-004_25C_75RH'];
  public singlebarChartType: ChartType = 'bar';
  public singlebarChartLegend = true;

  // public barChartData: ChartDataSets[] = [
  //   { data: [65, 59, 80, 81, 56, 55, 40], "hoverBackgroundColor": '#004090', label: 'Series A' },
  // ];
  public singlebarChartData = []
  // public singlebarChartData: ChartDataSets[] = [
  // { data: [3.49, 2.60, 1.5, -0.1], "hoverBackgroundColor": '#EDF4FD', label: 'Dimenhydrainate ' },
  // { data: [0.7, 0.7, 0.7, -3.7], "hoverBackgroundColor": '#f5c5a4', label: 'Sodium Stearyl Fumarate' },
  // { data: [1.8, 3.5, 10, 2], "hoverBackgroundColor": '#e6e1df', label: 'Hypromellose' },
  // { data: [-1.8, -0.5, -0.5, -0.5], "hoverBackgroundColor": '#e3df91', label: 'Eudragit EPO' },
  // { data: [0, 0, 0, 2], "hoverBackgroundColor": '#97cfd1', label: 'Starch' },

  // { data: [-0.30, -0.54, 0], "hoverBackgroundColor": '#EDF4FD', label: 'Asprin ' },
  // { data: [-0.09, 0.00, 0], "hoverBackgroundColor": '#f5c5a4', label: 'Water-o' },
  // { data: [-0.14, -0.03, 0], "hoverBackgroundColor": '#e6e1df', label: 'ethanol' },
  // { data: [0.00, 0, 0], "hoverBackgroundColor": '#e3df91', label: 'water_11' },
  // { data: [0, 0, 0, 2], "hoverBackgroundColor": '#97cfd1', label: 'Starch' },
  // ];

  public singlebarChartColors: Color[] = [
    { backgroundColor: '#004090' },
    { backgroundColor: '#f2741b' },
    { backgroundColor: '#9fa6a6' },
    { backgroundColor: '#f0e73e' },
    { backgroundColor: '#32e7ed' },

  ]




  constructor(private fb: FormBuilder,
    public _formBuilder: FormBuilder,
    private toastrService: ToastService,
    private _AdminService: AdminService, public authenticationService: AuthenticationService, private router: Router) {

    this.firstname = sessionStorage.getItem("firstname");
    this.lastname = sessionStorage.getItem("lastname")

    this.radiobtnclickjson = [{
      "checked": true,
      "name": "Single job visualization",
      "value": "SP",
    },
    {
      "checked": false,
      "name": "Multi job visualization",
      "value": "MP",
    }]

    this.JobidForm = this.fb.group({
      jobid: this.fb.array([
        this.fb.control(null)
      ])
    })

    this.JobidForm = this.fb.group({
      jobid: this.fb.array([
        this.fb.control(null)
      ])

    })


    this.firstjobform = this._formBuilder.group({
      firstjob: [''],
      secondjobform: [''],
      startdate: ['', Validators.required],
      enddate: ['', Validators.required],
      location: ['']
    });


    this.singlechart = this._formBuilder.group({
      jobselected: [''],

    });
  }

  ngOnInit(): void {

    // this.dataa = [
    //   {
    //     "Excipinent_name": "Phenol-o",
    //     "Jobdetails": [
    //       {
    //         "Jobid": 423,
    //         "Jobname": "P-193_SP_PRO1_may278_40C_75RH",
    //         "StabilityScore": "0.00",
    //         "ExcipinentName": "Phenol-o"
    //       },
    //       {
    //         "Jobid": 423,
    //         "Jobname": "P-193_SP_PRO1_may278_40C_75RH",
    //         "StabilityScore": "0.00",
    //         "ExcipinentName": "Phenol-o"
    //       },
    //       {
    //         "Jobid": 419,
    //         "Jobname": "P-290_SP_M27-J002-Admin_21.5C_78RH",
    //         "StabilityScore": 0,
    //         "ExcipinentName": "Mannitol"
    //       }
    //     ]
    //   },
    //   {
    //     "Excipinent_name": "Mannitol",
    //     "Jobdetails": [
    //       {
    //         "Jobid": 419,
    //         "Jobname": "P-290_SP_M27-J002-Admin_21.5C_78RH",
    //         "StabilityScore": "-0.06",
    //         "ExcipinentName": "Mannitol"
    //       },
    //       {
    //         "Jobid": 423,
    //         "Jobname": "P-193_SP_PRO1_may278_40C_75RH",
    //         "StabilityScore": 0,
    //         "ExcipinentName": "Phenol-o"
    //       }
    //     ]
    //   },
    //   {
    //     "Excipinent_name": "ethanol",
    //     "Jobdetails": [
    //       {
    //         "Jobid": 419,
    //         "Jobname": "P-290_SP_M27-J002-Admin_21.5C_78RH",
    //         "StabilityScore": "-0.02",
    //         "ExcipinentName": "ethanol"
    //       },
    //       {
    //         "Jobid": 423,
    //         "Jobname": "P-193_SP_PRO1_may278_40C_75RH",
    //         "StabilityScore": 0,
    //         "ExcipinentName": "Phenol-o"
    //       }
    //     ]
    //   },
    //   {
    //     "Excipinent_name": "methanol",
    //     "Jobdetails": [
    //       {
    //         "Jobid": 419,
    //         "Jobname": "P-290_SP_M27-J002-Admin_21.5C_78RH",
    //         "StabilityScore": "-0.17",
    //         "ExcipinentName": "methanol"
    //       },
    //       {
    //         "Jobid": 423,
    //         "Jobname": "P-193_SP_PRO1_may278_40C_75RH",
    //         "StabilityScore": 0,
    //         "ExcipinentName": "Phenol-o"
    //       }
    //     ]
    //   }
    // ]
    // for (var i = 0; i < this.dataa.length; i++) {
    //   console.log(this.dataa[i].Excipinent_name);

    //   var chartdata = [];
    //   console.log("i-------" + i)

    //   console.log("element-------smile" + this.dataa[i].Jobdetails.length)
    //   for (var j = 0; j < this.dataa[i].Jobdetails.length; j++) {
    //     console.log("element-------smile" + this.dataa[i].Jobdetails[j].Jobname)

    //     if (this.barChartLabels.length > 0) {

    //       if (!this.barChartLabels.includes(this.dataa[i].Jobdetails[j].Jobname)) {
    //         this.barChartLabels.push(this.dataa[i].Jobdetails[j].Jobname);
    //       }
    //     } else {
    //       this.barChartLabels.push(this.dataa[i].Jobdetails[j].Jobname);
    //     }
    //     chartdata.push(this.dataa[i].Jobdetails[j].StabilityScore)
    //   }
    //   var subdata = {
    //     data: chartdata,
    //     label: this.dataa[i].Excipinent_name,
    //     borderColor: '#17a2b8',
    //   }
    //   this.barChartData.push(subdata)
    //   console.log(this.barChartData);

    // }



    this.singlejobform = this._formBuilder.group({
      singlejobid: ['', Validators.required],
    });
    console.log(this.jobid);

    // this.JobidForm = this._formBuilder.group({
    //   multijobid: ['', Validators.required],
    // });

    this.getjobids();

  }

  getjobids() {
    this.loading = true
    this._AdminService.getjobids()
      .pipe(first())
      .subscribe((res: any) => {
        if (!res.isError) {
          this.loading = false
          console.log(res);
          this.jobids = res.responseMessage
          // this.dataSource = new MatTableDataSource(res.responseMessage);

        }
        else {
          this.loading = false
          const options = { opacity: 1, timeOut: 2000, tapToDismiss: true };
          this.toastrService.warning('', res.errorMessage, options);
          // setTimeout(() => {
          //   this.toastrService.clear(),2000
          // }, 2000);

        }
      },
        err => {
          const options = { opacity: 1, timeOut: 2000, tapToDismiss: true };
          console.log(err);

        });
  }

  jobname: any;
  jobidsonselect(ele) {
    console.log(ele);
    this.jobidsId = ele.value.jobid
    this.jobname = ele.value.jobname.replace(/\./g, "-");
    console.log(this.jobname);

  }
  getErrorMessage() {
    return this.jobid.hasError('required') ? 'Select job name' :
      '';

  }

  addPhone(): void {
    (this.JobidForm.get('jobid') as FormArray).push(
      this.fb.control("")
    );
    console.log(this.JobidForm.value);


    this.JobidForm.value.jobid.forEach(x => {

      if (x != undefined) {
        this.tempx.push(x.jobid)

      }

    });

    console.log(this.tempx);

  }
  removePhone(index) {
    (this.JobidForm.get('jobid') as FormArray).removeAt(index);
    // this.tempx.removeAt(index)
    this.tempx.splice(index, 1)

  }
  getPhonesFormControls(): AbstractControl[] {
    return (<FormArray>this.JobidForm.get('jobid')).controls
  }

  formsubmit() {
    console.log("formsubmit()");
    if (this.singlejobform.valid) {
      // if (this.singlejobid.valid) {

      console.log("validation");
      this.loading = true
      this._AdminService.getvisualtable(this.jobidsId)
        .pipe(first())
        .subscribe((res: any) => {
          if (!res.isError) {
            this.loading = false
            console.log(res);
            // this.jobids = res.responseMessage
            this.dataSource = new MatTableDataSource(res.responseMessage);

            if (res.responseMessage.length == 0) {
              this.aftersubmitsinglejob = true;
              this.listdata = true;
            } else {
              this.aftersubmitsinglejob = true;
              this.listdata = false;

            }
          }
          else {
            this.loading = false
            const options = { opacity: 1, timeOut: 2000, tapToDismiss: true };
            this.toastrService.warning('', res.errorMessage, options);
            // setTimeout(() => {
            //   this.toastrService.clear(),2000
            // }, 2000);

          }
        },
          err => {
            const options = { opacity: 1, timeOut: 2000, tapToDismiss: true };
            console.log(err);

          });
      // }
    }
    else {
      const options = { opacity: 1, timeOut: 2000, tapToDismiss: true };
      this.toastrService.warning('', "Please select Job name", options);
    }
  }

  tempx: any = []

  multijobidsonselect(ele) {
    console.log(ele.value.jobid);

    // const ischeckid = this.tempx.includes(ele.value.jobid)
    // console.log(ischeckid);

    // if (!ischeckid) {
    //   this.tempx.push(ele.value.jobid)

    // } else {

    //   const options = { opacity: 1, timeOut: 2000, tapToDismiss: true };
    //   this.toastrService.warning('', "Job name already exist", options);
    // }

    // console.log(this.tempx);

  }


  multiselectjobidsonselect(ele, i) {
    console.log(ele.value.jobid);
    // console.log(this.JobidForm.value);
    // console.log(i);

    // console.log(this.JobidForm.value.jobid[i]);

    // if (this.JobidForm.value.jobid.length > 1) {
    //   console.log("length-------");
    //   console.log(ele.value.jobid);
    //   console.log(this.JobidForm.value.jobid[i]);


    //   const ischeckid = this.tempx.includes(ele.value.jobid)

    //   if (ischeckid) {

    //     (this.JobidForm.get('jobid') as FormArray).removeAt(i);
    //     this.tempx.splice(i, 1)

    //     const options = { opacity: 1, timeOut: 2000, tapToDismiss: true };
    //     this.toastrService.warning('', "Job name already exist", options);
    //   }

    // }

    // }
    // console.log(this.JobidForm.value.jobid[i]);
    // console.log(this.JobidForm.value);

    // console.log(this.tempx);
  }

  ischeckempty: boolean;
  jobidpayload: any = []
  multiformformsubmit() {

    console.log(this.JobidForm.value.jobid);




    if (this.JobidForm.value.jobid[0] != null) {
      //  return object check
      const emptycheck = this.JobidForm.value.jobid.every(x => x != "")
      console.log(emptycheck);
      if (emptycheck) {
        const foundDuplicateName = this.JobidForm.value.jobid.find((nnn, index) => {
          return this.JobidForm.value.jobid.find((x, ind) => x.jobid === nnn.jobid && index !== ind)
        })

        console.log(foundDuplicateName)

        if (foundDuplicateName == undefined) {

          // this.JobidForm.value


          console.log("singlejobformsubmit------" + JSON.stringify(this.firstjobform.value.firstjob));
          console.log(this.JobidForm.value.jobid[0]);
          // var x = []
          this.jobidpayload = []
          if (this.JobidForm.value.jobid[0] != null) {

            console.log("multijobformsubmit()" + JSON.stringify(this.firstjobform.value.firstjob), this.JobidForm.value.jobid);


            // x.push(this.firstjobform.value.firstjob.jobid)
            for (let temp of this.JobidForm.value.jobid) {
              this.jobidpayload.push(temp.jobid)
            }

            console.log(this.jobidpayload);


            // this.JobidForm.value.jobid
            this._AdminService.getmultijob(this.jobidpayload)
              .pipe(first())
              .subscribe((res: any) => {
                if (!res.isError) {
                  this.loading = false
                  this.multitableview = true
                  this.chartAPI();
                  console.log(res.responseMessage);
                  var ex = []
                  var ex1 = []

                  this.tempparray = []
                  this.headerinfotempparray = []
                  this.tablejobname = []

                  for (let i of res.responseMessage.headerInformation) {

                    var arrt = {
                      "title": i.molA
                    }
                    ex1.push(arrt)
                    var arrt = {
                      "title": i.molB
                    }
                    ex1.push(arrt)
                    var arrt = {
                      "title": i.molC
                    }
                    ex1.push(arrt)
                    this.tablejobname.push(i.jobname)

                  }
                  console.log(this.tablejobname);

                  var obj = {
                    "title": ex1
                  }
                  this.headerinfotempparray.push(ex1)
                  this.exam = this.headerinfotempparray.flat()
                  console.log(this.exam);

                  for (let i of res.responseMessage.moleculesjoblist) {
                    for (let j of i.joblist) {

                      // console.log(i.joblist.length);
                      // console.log(res.responseMessage.headerInformation.length);
                      if (j.rt == null) {
                        ex.push("-")

                      } else {
                        ex.push(j.rt)

                      }


                      if (j.wtfraction == null) {
                        ex.push("-")

                      } else {
                        ex.push(j.wtfraction)

                      }

                      if (j.stability_score == null) {
                        ex.push("-")

                      } else {
                        ex.push(j.stability_score)

                      }

                      // ex.push(j.rt)
                      // ex.push(j.wtfraction)
                      // ex.push(j.stability_score)

                    }

                    var arra = {
                      "moleculename": 'water',
                      "data": ex
                    }
                    this.tempparray.push(arra)

                    ex = []

                  }
                  console.log(ex);
                  console.log(this.tempparray);


                  for (let i in res.responseMessage.moleculeslist) {

                    this.tempparray[i].moleculename = res.responseMessage.moleculeslist[i].moleculename
                  }
                  console.log(this.tempparray);


                }
                else {
                  this.loading = false
                  const options = { opacity: 1, timeOut: 2000, tapToDismiss: true };
                  this.toastrService.warning('', res.errorMessage, options);

                }
              },
                err => {
                  const options = { opacity: 1, timeOut: 2000, tapToDismiss: true };
                  console.log(err);

                });



            console.log("validation");
          }

        } else {
          const options = { opacity: 1, timeOut: 2000, tapToDismiss: true };
          this.toastrService.warning('', foundDuplicateName.jobname + " " + "already selected", options);
        }

      } else {
        const options = { opacity: 1, timeOut: 2000, tapToDismiss: true };
        this.toastrService.warning('', "Please select Job name", options);
      }

    } else {
      const options = { opacity: 1, timeOut: 2000, tapToDismiss: true };
      this.toastrService.warning('', "Please select Job name", options);
    }

    // -------------------------------------------------------------------




  }



  chartAPI() {

    this.dataa = []
    console.log(this.dataa);
    this.barChartLabels = []
    this.barChartData = []

    this.singlebarChartLabels = []
    this.singlebarChartData = []

    this._AdminService.getchart(this.jobidpayload)
      .pipe(first())
      .subscribe((res: any) => {
        if (!res.isError) {
          this.loading = false
          console.log(res.responseMessage);
          this.dataa = res.responseMessage


          // ----------------------------------------------------for (var i = 0; i < this.getsmilelist.length; i++) {
          // chartdata = [];
          //   console.log("i-------" + i)

          //   console.log("element-------smile" + this.dataa  [i].smiledetails.length)
          //   for (var j = 0; j < this.getsmilelist[i].smiledetails.length; j++) {
          //     console.log("element-------smile" + this.getsmilelist[i].smiledetails[j].smile)

          //     if (this.barChartLabels.length > 0) {

          //       if (!this.barChartLabels.includes(this.getsmilelist[i].smiledetails[j].smile)) {
          //         this.barChartLabels.push(this.getsmilelist[i].smiledetails[j].smile);
          //       }
          //     } else {
          //       this.barChartLabels.push(this.getsmilelist[i].smiledetails[j].smile);
          //     }
          //     chartdata.push(this.getsmilelist[i].smiledetails[j].logsvalue)
          //   }
          //   var subdata = {
          //     data: chartdata,
          //     label: this.getsmilelist[i].version,
          //     borderColor: '#17a2b8',
          //   }
          //   this.barChartData.push(subdata)
          // }
          // ------------------------------------------------------------------------------
          this.barChartLabels = []
          this.barChartData = []
          this.singlebarChartLabels = []
          this.singlebarChartData = []
          var matdropdown = []

          for (var i = 0; i < this.dataa.length; i++) {
            console.log(this.dataa[i].Excipinent_name);
            matdropdown.push(this.dataa[i].Excipinent_name)

            var chartdata = [];
            console.log("i-------" + i)

            console.log("element-------" + this.dataa[i].Jobdetails.length)
            for (var j = 0; j < this.dataa[i].Jobdetails.length; j++) {
              console.log("element-------" + this.dataa[i].Jobdetails[j].Jobname)

              if (this.barChartLabels.length > 0) {

                if (!this.barChartLabels.includes(this.dataa[i].Jobdetails[j].Jobname)) {
                  this.barChartLabels.push(this.dataa[i].Jobdetails[j].Jobname);
                }
              } else {
                this.barChartLabels.push(this.dataa[i].Jobdetails[j].Jobname);
              }
              chartdata.push(this.dataa[i].Jobdetails[j].StabilityScore)
            }
            var subdata = {
              data: chartdata,
              label: this.dataa[i].Excipinent_name,
              barPercentage: 0.5,
              // barThickness: 100,

              // borderColor: '#17a2b8',
            }
            this.barChartData.push(subdata)
            console.log(this.barChartData);

          }
          // --------------------------------------------------------------
          var singlechartdata = []
          this.singlebarChartLabels = []
          this.singlebarChartData = []
          // for (var i = 0; i < this.dataa[0].Jobdetails.length; i++) {
          //   singlechartdata.push(this.dataa[0].Jobdetails[i].StabilityScore)
          //   console.log(singlechartdata);

          //   var singlesubdata = {
          //     data: singlechartdata,
          //     label: this.dataa[0].Excipinent_name,
          //     // borderColor: '#17a2b8',
          //   }
          //   console.log(this.singlebarChartData);

          //   this.singlebarChartData.push(singlesubdata)
          //   console.log(this.singlebarChartData);
          //   this.singlebarChartLabels.push(this.dataa[0].Jobdetails[i].Jobname)
          // }
          var temparr = []
          temparr.push(this.dataa[0])

          for (var i = 0; i < temparr.length; i++) {
            console.log(temparr[i].Excipinent_name);
            // matdropdown.push(this.dataa[i].Excipinent_name)

            var chartdata = [];
            console.log("i-------" + i)

            console.log("element-------" + temparr[i].Jobdetails.length)
            for (var j = 0; j < temparr[i].Jobdetails.length; j++) {
              console.log("element-------" + temparr[i].Jobdetails[j].Jobname)

              if (this.singlebarChartLabels.length > 0) {

                if (!this.singlebarChartLabels.includes(temparr[i].Jobdetails[j].Jobname)) {
                  this.singlebarChartLabels.push(temparr[i].Jobdetails[j].Jobname);
                }
              } else {
                this.singlebarChartLabels.push(temparr[i].Jobdetails[j].Jobname);
              }
              chartdata.push(temparr[i].Jobdetails[j].StabilityScore)
            }
            var subdataa = {
              data: chartdata,
              label: temparr[i].Excipinent_name,
              barPercentage: 0.5,
              barThickness: 100,
              // borderColor: '#17a2b8',
            }
            this.singlebarChartData.push(subdataa)
            console.log(this.singlebarChartData);
            // this.singlebarChartLabels.push(temparr[i].Jobdetails[j].Jobname)
          }
          console.log(this.dataa[0].Excipinent_name);
          this.selected = this.dataa[0].Excipinent_name;
          // this.selectexcipient = this.dataa[0].Excipinent_name
          // this.singlechart.value.jobselected = this.dataa[0].Excipinent_name
        }
        else {
          this.loading = false
          const options = { opacity: 1, timeOut: 2000, tapToDismiss: true };
          this.toastrService.warning('', res.errorMessage, options);

        }
      },
        err => {
          const options = { opacity: 1, timeOut: 2000, tapToDismiss: true };
          console.log(err);

        });

  }
  selected: any;
  send(values) {
    console.log(values);
  }
  logout() {
    this.authenticationService.logout();
    this.router.navigate(['']);
  }

  csvdownload() {
    console.log(this.jobidsId);
    this.loading = true
    this._AdminService.downloadcsv(this.jobidsId)
      .pipe(first())
      .subscribe((res: any) => {
        if (!res.isError) {
          this.loading = false
          console.log(res);
          const newBlob = new Blob([res], { type: 'application/csv' });
          this.data = window.URL.createObjectURL(res);
          const file_path = this.data;
          const down = document.createElement('A') as HTMLAnchorElement;
          down.href = file_path;
          down.download = this.jobname
          document.body.appendChild(down);
          down.click();
          document.body.removeChild(down);

        }
        else {
          this.loading = false
          const options = { opacity: 1, timeOut: 2000, tapToDismiss: true };
          this.toastrService.warning('', res.errorMessage, options);

        }
      },
        err => {
          const options = { opacity: 1, timeOut: 2000, tapToDismiss: true };
          console.log(err);

        });
  }

  pdfdownload() {
    console.log(this.jobidsId);
    this.jobname.split('.').join("- ");
    console.log(this.jobname);
    
    this.loading = true
    this._AdminService.downloadpdf(this.jobidsId)
      .pipe(first())
      .subscribe((res: any) => {
        if (!res.isError) {
          this.loading = false
          console.log(res);
          const newBlob = new Blob([res], { type: 'application/pdf' });
          this.data = window.URL.createObjectURL(res);
          const file_path = this.data;
          const down = document.createElement('A') as HTMLAnchorElement;
          down.href = file_path;
          down.download = this.jobname
          document.body.appendChild(down);
          down.click();
          document.body.removeChild(down);

        }
        else {
          this.loading = false
          const options = { opacity: 1, timeOut: 2000, tapToDismiss: true };
          this.toastrService.warning('', res.errorMessage, options);

        }
      },
        err => {
          const options = { opacity: 1, timeOut: 2000, tapToDismiss: true };
          console.log(err);

        });
  }



  multicsvdownload() {
    console.log(this.jobidpayload);
    this.loading = true
    this._AdminService.multidownloadcsv(this.jobidpayload)
      .pipe(first())
      .subscribe((res: any) => {
        if (!res.isError) {
          this.loading = false
          console.log(res);
          const newBlob = new Blob([res], { type: 'application/csv' });
          this.data = window.URL.createObjectURL(res);
          const file_path = this.data;
          const down = document.createElement('A') as HTMLAnchorElement;
          down.href = file_path;
          down.download = "Multiple-jobs"
          document.body.appendChild(down);
          down.click();
          document.body.removeChild(down);

        }
        else {
          this.loading = false
          const options = { opacity: 1, timeOut: 2000, tapToDismiss: true };
          this.toastrService.warning('', res.errorMessage, options);

        }
      },
        err => {
          const options = { opacity: 1, timeOut: 2000, tapToDismiss: true };
          console.log(err);

        });
  }
  multipdfdownload() {
    console.log(this.jobidpayload);
    this.loading = true
    this._AdminService.multidownloadpdf(this.jobidpayload)
      .pipe(first())
      .subscribe((res: any) => {
        if (!res.isError) {
          this.loading = false
          console.log(res);
          const newBlob = new Blob([res], { type: 'application/csv' });
          this.data = window.URL.createObjectURL(res);
          const file_path = this.data;
          const down = document.createElement('A') as HTMLAnchorElement;
          down.href = file_path;
          down.download = "Multiple-jobs"
          document.body.appendChild(down);
          down.click();
          document.body.removeChild(down);

        }
        else {
          this.loading = false
          const options = { opacity: 1, timeOut: 2000, tapToDismiss: true };
          this.toastrService.warning('', res.errorMessage, options);

        }
      },
        err => {
          const options = { opacity: 1, timeOut: 2000, tapToDismiss: true };
          console.log(err);

        });
  }

  dataaselect: any = [];
  jobidchartonselect(ele) {
    console.log(ele.value);
    // --------------------------------------------------------------
    this.dataaselect = []
    var singlechartdata = []
    this.singlebarChartLabels = []
    this.singlebarChartData = []
    this.dataaselect.push(ele.value)
    // this.dataa = ele.value
    console.log(this.dataaselect);

    for (var i = 0; i < this.dataaselect.length; i++) {
      console.log(this.dataaselect[i].Excipinent_name);
      // matdropdown.push(this.dataa[i].Excipinent_name)

      var chartdata = [];
      console.log("i-------" + i)

      console.log("element-------" + this.dataaselect[i].Jobdetails.length)
      for (var j = 0; j < this.dataaselect[i].Jobdetails.length; j++) {
        console.log("element-------" + this.dataaselect[i].Jobdetails[j].Jobname)

        if (this.singlebarChartLabels.length > 0) {

          if (!this.singlebarChartLabels.includes(this.dataaselect[i].Jobdetails[j].Jobname)) {
            this.singlebarChartLabels.push(this.dataaselect[i].Jobdetails[j].Jobname);
          }
        } else {
          this.singlebarChartLabels.push(this.dataaselect[i].Jobdetails[j].Jobname);
        }
        chartdata.push(this.dataaselect[i].Jobdetails[j].StabilityScore)
      }
      var subdata = {
        data: chartdata,
        label: this.dataaselect[i].Excipinent_name,
        barThickness: 100,

        // borderColor: '#17a2b8',
      }
      this.singlebarChartData.push(subdata)
      console.log(this.singlebarChartData);

    }



    // ----------------------------------------------------------
    // for (var i = 0; i < ele.value.Jobdetails.length; i++) {
    //   singlechartdata.push(ele.value.Jobdetails[i].StabilityScore)
    //   console.log(ele.value.Jobdetails[i]);
    //   console.log(singlechartdata);

    //   var singlesubdata = {
    //     data: singlechartdata,
    //     label: ele.value.Jobdetails[i].ExcipinentName,
    //     // borderColor: '#17a2b8',
    //   }
    //   this.singlebarChartLabels.push(ele.value.Jobdetails[i].Jobname)
    //   console.log(this.singlebarChartData);

    //   this.singlebarChartData.push(singlesubdata)
    //   console.log(this.singlebarChartData);

    // }
  }
}
