import { Component, OnInit } from '@angular/core';
import { FormGroup } from '@angular/forms';
import { FormBuilder, Validators } from '@angular/forms';
import { AdminService } from 'src/app/_Services/admin.sevice';
import { ToastService } from 'ng-uikit-pro-standard';
import { Router } from '@angular/router';
import { first } from 'rxjs/operators';
// import { Router } from '@angular/router';
import { MatDialogRef } from '@angular/material/dialog';

@Component({
  selector: 'app-addproject',
  templateUrl: './addproject.component.html',
  styleUrls: ['./addproject.component.css']
})
export class AddprojectComponent implements OnInit {

  maxDate: any;
  myStartDate: any;
  loading: boolean;
  status: any;
  displayname: any;
  Status: any;
  submit: boolean;

  constructor(public _formBuilder: FormBuilder, private toastrService: ToastService,
    private _AdminService: AdminService, private router: Router, private dialogRef: MatDialogRef<AddprojectComponent>) { }
  addprojectGroup: FormGroup

  ngOnInit(): void {
    this.addprojectGroup = this._formBuilder.group({
      Name: ['', [Validators.required]],
      Code: ['', [Validators.required]],
      Sponsor: ['', [Validators.required]],
      // Date: ['',[Validators.required]],
      startdate: ['', [Validators.required]],
      Status: ['', [Validators.required]],
    });

    this.myStartDate = new Date();


    this.getstatus()
  }
  getstatus() {
    this.loading = true
    this._AdminService.getstatus()
      .pipe(first())
      .subscribe((res: any) => {
        if (!res.isError) {
          this.loading = false
          console.log(res);
          this.Status = res.responseMessage
        }
        else {
          const options = { opacity: 1, timeOut: 2000, tapToDismiss: true };
          this.toastrService.warning('', res.errorMessage, options);
        }
      },
        err => {
          const options = { opacity: 1, timeOut: 2000, tapToDismiss: true };
          console.log(err);

        });
  }
  formsubmit() {
    //   console.log("submit")
    if (this.addprojectGroup?.value.Name.trim() == '' || this.addprojectGroup?.value.Name.trim() == null ||
      this.addprojectGroup?.value.Code.trim() == '' || this.addprojectGroup?.value.Code.trim() == null ||
      this.addprojectGroup?.value.Sponsor.trim() == '' || this.addprojectGroup?.value.Sponsor.trim() == null
    ) {
      const options = { opacity: 1, timeOut: 2000, tapToDismiss: true };
      this.toastrService.warning('', 'Please fill the mandatory fields', options);
      this.loading = false;
      return;
    }
    else if (this.addprojectGroup?.value?.startdate == '') {
      const options = { opacity: 1, timeOut: 2000, tapToDismiss: true };
      this.toastrService.warning('', 'Please select startdate', options);
      this.loading = false;
      return;
    }
    else if (this.addprojectGroup?.value?.Status == '') {
      const options = { opacity: 1, timeOut: 2000, tapToDismiss: true };
      this.toastrService.warning('', 'Please select status', options);
      this.loading = false;
      return;
    }
    //  if(this.addprojectGroup?.controls?.Name?.invalid || this.addprojectGroup?.controls?.Code?.invalid
    // || this.addprojectGroup?.controls?.Sponsor?.invalid || this.addprojectGroup?.controls?.startdate?.invalid || this.addprojectGroup?.controls?.Status?.invalid){
    //   const options = { opacity: 1, timeOut: 2000, tapToDismiss: true };
    //   this.toastrService.warning('', 'Please enter valid details', options);
    //   this.loading = false;
    //   return;
    // }

    // else {
    // if (this.submit == true) {
    console.log("submitform");
    let payload = {
      "Project_Name": this.addprojectGroup.value.Name,
      "Project_Code": this.addprojectGroup.value.Code,
      "Sponsor": this.addprojectGroup.value.Sponsor,
      "Start_Date": this.addprojectGroup.value.startdate,
      "Projectstatusid": this.addprojectGroup.value.Status,
    }
    console.log(payload);
    this.loading = true
    this._AdminService.createproject(payload)
      .pipe(first())
      .subscribe((res: any) => {
        if (!res.error) {
          this.loading = false
          console.log(res);
          const options = { opacity: 1, timeOut: 2000, tapToDismiss: true };
          this.toastrService.success('', res.responseMessage, options);
          // this.router.navigate(['/userlist']);
          this.dialogRef.close({ data: "yes" });
          
          this.addprojectGroup.reset();

        }
        else {
          console.log(res.errorMessage)
          const options = { opacity: 1, timeOut: 2000, tapToDismiss: true };
          this.toastrService.warning('', res.errorMessage, options);
        }
      },
        // err => {
        //   //  this.dialogRef.close({ data: err });
        //   const options = { opacity: 1, timeOut: 2000};
        //   this.toastrService.warning('', err?.error,options);
        // }
      );
  }

  cancelclick() {
    this.dialogRef.close({ data: "no" });

  }
}
// }}
