import { ComponentFixture, TestBed } from '@angular/core/testing';

import { JobcreationSavemoleculesComponent } from './jobcreation-savemolecules.component';

describe('JobcreationSavemoleculesComponent', () => {
  let component: JobcreationSavemoleculesComponent;
  let fixture: ComponentFixture<JobcreationSavemoleculesComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ JobcreationSavemoleculesComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(JobcreationSavemoleculesComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
