import { Component, OnInit, Inject } from '@angular/core';
import { FormBuilder, FormGroup } from '@angular/forms';
import { MatDialogRef, MAT_DIALOG_DATA } from '@angular/material/dialog';
import { first } from 'rxjs/operators';
import { AdminService } from 'src/app/_Services/admin.sevice';

@Component({
  selector: 'app-jobcreation-savemolecules',
  templateUrl: './jobcreation-savemolecules.component.html',
  styleUrls: ['./jobcreation-savemolecules.component.css']
})
export class JobcreationSavemoleculesComponent implements OnInit {

  loading: boolean;
  constructor(private _formBuilder: FormBuilder,
    private _AdminService: AdminService,
    public dialogRef: MatDialogRef<JobcreationSavemoleculesComponent>,
    @Inject(MAT_DIALOG_DATA) public data: any) {
  }

  ngOnInit(): void {
    console.log(this.data);

  }
  onNoClick(): void {
    this.dialogRef.close();
  }
  toggleReadonly() {
    this.dialogRef.close({ data: true });
  }
}
