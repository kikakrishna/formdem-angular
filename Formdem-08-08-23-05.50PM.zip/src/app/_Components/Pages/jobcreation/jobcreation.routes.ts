import { RouterModule } from "@angular/router";

// import { StatistictoolsComponent } from "./statistictools.component";
import { JobcreationComponent } from "./jobcreation.component";
export const JobcreationRoutes: RouterModule [] = [
    {
        path: '',
        component: JobcreationComponent
    }
]