import { Component, OnInit, ViewChild, ElementRef } from '@angular/core';
import { FormGroup } from '@angular/forms';
import { FormBuilder, Validators, FormControl, FormArray, NgForm } from '@angular/forms';
import { Observable, ReplaySubject, Subject } from 'rxjs';
import { ToastService } from 'ng-uikit-pro-standard';
import { AdminService } from 'src/app/_Services/admin.sevice';
import { first, retry, take, takeUntil, map, startWith } from 'rxjs/operators';
import { AuthenticationService } from 'src/app/_Services/authentication.service';
import { Router } from '@angular/router';
import * as moment from 'moment';
import { JobcreationSavemoleculesComponent } from '../jobcreation-savemolecules/jobcreation-savemolecules.component';
import { MatDialogRef, MAT_DIALOG_DATA } from '@angular/material/dialog';
import { MatDialog } from '@angular/material/dialog';

@Component({
  selector: 'app-jobcreation',
  templateUrl: './jobcreation.component.html',
  styleUrls: ['./jobcreation.component.css']
})
export class JobcreationComponent implements OnInit {
  createprojectGroup: FormGroup;
  addForm: FormGroup;
  addFormapi: FormGroup;
  addFormproto: FormGroup;
  rows: FormArray;
  rowsapi: FormArray;
  rowsapiproto: FormArray;
  project: any = [];
  addformjson: FormArray;
  itemForm: FormGroup;
  empForm: FormGroup;
  apiinformationForm: FormGroup;
  PrototypeJobSubmission: FormGroup;
  sample111: FormGroup;
  sample: FormGroup;
  arraynumbers: any;
  containers = [];
  prototyperadiobtn: any;
  divNameMap = {};
  divNameMappppp = {};
  filteredOptions: Observable<any[]>;
  filteredOptionsapi: Observable<any[]>;
  filteredOptionsapiname: Observable<any[]>;


  molearray: Observable<any[]>;
  selectedOption: any;
  jsondata: any = [];
  jsondatasubmission: any = [];
  moleculediv: Boolean = true;
  multiplediv: Boolean;
  uploaddiv: Boolean;
  singlediv: Boolean = true;
  prototype: any;
  firstname: string;
  lastname: string;
  excipinentname: any;
  todaydate = new Date();
  // payloaddate = new Date();
  loading: boolean;

  curr_hour: any;
  curr_min: any;
  curr_sec: any;
  paloaddate: any;
  currentdate: any;
  excippinentaddtable: boolean = false;

  getexcipinet: any = []
  getwtfractionname: any = []
  getwtfractionvalue: any = []

  constructor(public _formBuilder: FormBuilder,
    private fbmolecule: FormBuilder,
    private fbapiinformation: FormBuilder,
    private fbapiinform: FormBuilder,
    private fbprototype: FormBuilder,
    private fbsample: FormBuilder,
    private fb: FormBuilder,
    private toastrService: ToastService,
    private _AdminService: AdminService,
    public authenticationService: AuthenticationService,
    private router: Router,
    // public dialogRef: MatDialogRef<JobcreationSavemoleculesComponent>,
    public dialog: MatDialog,
  ) {
    this.firstname = sessionStorage.getItem("firstname");
    this.lastname = sessionStorage.getItem("lastname");
    this.addForm = this.fbmolecule.group({
      items: [true, Validators.required],
      items_value: ['no', Validators.required]
    });
    this.addFormapi = this.fbapiinform.group({
      items: [true, Validators.required],
      items_value: ['no', Validators.required]
    });
    this.addFormproto = this.fbprototype.group({
      items: [true, Validators.required],
      items_value: ['no', Validators.required]
    });

    this.rows = this.fbmolecule.array([]);
    this.rowsapi = this.fbapiinform.array([]);
    this.rowsapiproto = this.fbprototype.array([]);

  }

  ngOnInit(): void {
    console.log(this.uploadedfileres);


    this.prototyperadiobtn = "SP"
    this.curr_hour = this.todaydate.getHours();
    this.curr_min = this.todaydate.getMinutes();
    // this.paloaddate = this.todaydate.toUTCString()
    this.paloaddate = this.todaydate.toISOString();
    this.paloaddate = moment(this.todaydate).format();
    var date = moment(this.todaydate).subtract(10, 'days').calendar();
    console.log(date);


    this.curr_sec = this.todaydate.getSeconds();

    this.currentdate = moment(this.todaydate).format('DD-MM-YYYY');
    // const time = moment(this.todaydate).format('HH-MM-SS');
    console.log(this.paloaddate);
    // console.log(this.paloaddate.toISOString());
    // const hour = this.paloaddate.getUTCHours();
    // const minute = this.paloaddate.getUTCMinutes();
    // console.log("time-------------", hour + minute);

    this.createprojectGroup = this._formBuilder.group({
      Project: ['', Validators.required],
      Prototype: ['', Validators.required],
      Jobdescription: ['', Validators.required],
    });
    this.sample111 = this._formBuilder.group({
      test: ['', Validators.required],

    });
    this.PrototypeJobSubmission = this._formBuilder.group({
      jobname: ['', Validators.required,],
      // temperature: ['', Validators.required], Validators.pattern('^[0-9]*$')
      temperature: ['', [Validators.required, Validators.pattern(/^[0-9]+([.][0-9]{0,2})?$/)]],
      // temperature: ['', [Validators.required, Validators.pattern('^[0-9]*$')]],


      RH: ['', Validators.required],
    });

    this.sample = this.fbsample.group({
      samplearray: this.fbsample.array([])
    });



    this.apiinformationForm = this.fbapiinformation.group({
      filters: this.fbapiinformation.array([])
    });

    this.jsondata = [{
      "checked": true,
      "name": "Single Molecule Smiles",
      "value": 1,
    },
    {
      "checked": false,
      "name": "File Upload SDF / Mol2",
      "value": 2,
    }]


    this.jsondatasubmission = [{
      "checked": true,
      "name": "Single Prototype Job Submission",
      "value": "SP",
    },
    {
      "checked": false,
      "name": "Multiple Prototype Job Submission",
      "value": "MP",
    }]

    this.selectedOption = this.jsondata[0].value;
    this.addForm.addControl('rows', this.rows);
    this.addFormapi.addControl('rowsapi', this.rowsapi);
    this.addFormproto.addControl('rowsapiproto', this.rowsapiproto);



    this.onAddRowAPI()
    // this.onAddRowAPI()
    this.onAddRowproto()
    // this.onAddRowproto()

    this.seedFiltersFormArray()
    this.add();



    // project API
    this.getproject();
    // proto API
    this.getproto();


    console.log(this.rows.value);

    // API propertis
    this.empForm = this.fb.group({
      employees: this.fb.array([])
    });


    this.addEmployee()


  }

  getproto() {
    this.loading = true
    this._AdminService.getprototye()
      .pipe(first())
      .subscribe((res: any) => {
        if (!res.isError) {
          this.loading = false
          console.log(res);
          this.prototype = res.responseMessage

        }
        else {
          this.loading = false
          const options = { opacity: 1, timeOut: 2000, tapToDismiss: true };
          this.toastrService.warning('', res.errorMessage, options);
          // setTimeout(() => {
          //   this.toastrService.clear(),2000
          // }, 2000);

        }
      },
        err => {
          const options = { opacity: 1, timeOut: 2000, tapToDismiss: true };
          console.log(err);

        });
  }
  getproject() {
    this.loading = true
    this._AdminService.getproject()
      .pipe(first())
      .subscribe((res: any) => {
        if (!res.isError) {
          this.loading = false
          console.log(res);
          this.project = res.responseMessage

        }
        else {
          this.loading = false
          const options = { opacity: 1, timeOut: 2000, tapToDismiss: true };
          this.toastrService.warning('', res.errorMessage, options);
          // setTimeout(() => {
          //   this.toastrService.clear(),2000
          // }, 2000);

        }
      },
        err => {
          const options = { opacity: 1, timeOut: 2000, tapToDismiss: true };
          console.log(err);

        });
  }

  changeType(ele) {
    console.log(ele.value);
    if (ele.value == 1) {
      this.moleculediv = true
      this.uploaddiv = false
    } else {
      this.uploaddiv = true
      this.moleculediv = false

    }

  }

  get addDynamicRow() {
    return this.addForm.get('rows') as FormArray;
  }

  onAddRow() {
    this.excippinentaddtable = true;
    this.disablefield = true;
    this.rows.push(this.createItemFormGroup());
    console.log(this.rows.value)
    if (this.rows.value.length > 0) {
      // this.savemoleculesbtn = false;
      this.savemoleculesbtnhide = true;
    }
  }


  createItemFormGroup(): FormGroup {
    return this.fbmolecule.group({
      excipientname: null,
      smiles: null,
      charge: null,
      isdelete: true,
      readonly: false
    });
  }

  onRemoveRow(rowIndex: number, elerow) {

    console.log(elerow);

    this.rows.removeAt(rowIndex);
    console.log(this.rows.value);



    console.log(this.rows.value.length);


    if (this.rows.value.length == 0) {
      // this.savemoleculesbtn = true;
      this.excippinentaddtable = false;
      this.savemoleculesbtnhide = false;

    }


  }



  // API-section start--------------------------------------------------------
  onAddRowAPI() {
    this.rowsapi.push(this.createItemFormGroupApi());
    console.log(this.rowsapi.value)

  }

  createItemFormGroupApi(): FormGroup {
    return this.fbapiinform.group({
      Name: null,
      Temp: null,
      Title: null
    });
  }

  onRemoveRowAPI(rowIndex: number) {
    this.rowsapi.removeAt(rowIndex);
  }


  get addDynamicRowapi() {
    return this.addFormapi.get('rowsapi') as FormArray;
  }


  // apiinformationfor-add------------------------
  addFilterToFiltersFormArray() {
    this.filtersFormArray.push(this.createFilterGroupapi());
    console.log(this.filtersFormArray);

  }

  seedFiltersFormArray() {
    console.log("seedFiltersFormArray");

    const formGroup = this.createFilterGroupapi();
    formGroup.addControl('value', this.getFormControl());


  }

  createFilterGroupapi() {
    return this.fbapiinformation.group({
      Apiname: null,
      Mp: null,
      Hfus: null,

    });
  }

  get filtersFormArray() {
    return (<FormArray>this.apiinformationForm.get('filters'));
  }

  removeFilterFromFiltersFormArray(index) {
    this.filtersFormArray.removeAt(index);
  }

  getFormControl() {
    return this.fbapiinformation.control(null);
  }


  // ---------------------prototype submission
  changeTypesubmission(ele) {
    console.log(ele.value);
    this.prototyperadiobtn = ele.value
    if (ele.value == "SP") {
      this.singlediv = true
      this.multiplediv = false
    } else {
      this.multiplediv = true
      this.singlediv = false

    }
  }

  // disablefield :boolean = true;
  onAddRowproto() {
    console.log(this.addFormproto);
    // this.excipinentname = ""
    console.log(this.rowsapiproto.value)


    this.rowsapiproto.push(this.createItemFormGroupproto());
    // setTimeout(() => {

    // }, 100);
    for (let i of this.addFormproto.value.rowsapiproto) {
      i.ExcipientName = "test"
    }

    // if(this.addFormproto.value.rowsapiproto[0].ExcipientName == ''){
    //   console.log("emoty");

    //   this.addFormproto.value.rowsapiproto[0].ExcipientName = "test"

    // }
    // this.addFormproto.value.rowsapiproto.get("ExcipientName").setValue('hai')
    console.log(this.addFormproto.value.rowsapiproto);
    this.filteredOptions = null;
    this.mainarray = this.addFormproto.value.rowsapiproto
    console.log(this.sample111.value.test);

  }
  mainarray: any;
  createItemFormGroupproto(): FormGroup {
    return this.fbprototype.group({
      ExcipientName: "",
      Wtfraction: "",
      ExcipientId: "",
    });
  }

  onRemoveRowproto(rowIndex: number) {
    this.rowsapiproto.removeAt(rowIndex);
    this.checkidarraay.splice(rowIndex, 1)
    console.log(this.checkidarraay);

  }
  checkidarraay: any = []

  get addDynamicRowproto() {
    return this.addFormproto.get('rowsapiproto') as FormArray;
  }



  drugArray: any = [];
  // molearray: any = [];
  patientControl = new FormControl();


  getDropdown(event) {
    console.log(event.target.value);
    console.log(this.addFormproto.value.rowsapiproto);
    for (let i of this.addFormproto.value.rowsapiproto) {
      // if (i.ExcipientName.trim() != "") {
      console.log(true);
      if (event.target.value.length >= 2) {
        this.loading = true
        this._AdminService.getmoleculekeyup(event.target.value)
          .pipe(first())
          .subscribe((res: any) => {
            if (!res.isError) {
              this.loading = false
              console.log(res);
              // this.project = res.responseMessage
              console.log(this.addFormproto.value.rowsapiproto);

              this.drugArray = res.responseMessage;
              console.log(this.drugArray);
              this.molearray = res.responseMessage
              this.filteredOptions = this.patientControl.valueChanges
                .pipe(
                  startWith(''),
                  map(value => this._filter(value)),

                );
              console.log(this.filteredOptions)
            }
            else {
              this.loading = false
              const options = { opacity: 1, timeOut: 2000, tapToDismiss: true };
              this.toastrService.warning('', res.errorMessage, options);
              // setTimeout(() => {
              //   this.toastrService.clear(),2000
              // }, 2000);

            }
          },
            err => {
              const options = { opacity: 1, timeOut: 2000, tapToDismiss: true };
              console.log(err);

            });

      }
      // } else {
      //   console.log("false");
      //   const options = { opacity: 1, timeOut: 2000, tapToDismiss: true };
      //   this.toastrService.warning('', "ExcipientName should not be empty", options);
      // }
    }



    if (event.target.value.length == 0) {
      this.filteredOptions = null;
    }

  }

  private _filter(value: string): string[] {
    const filterValue = value;
    console.log(filterValue);

    if (this.drugArray) {
      return this.drugArray.filter(option => option.excipientname.toLowerCase().includes(filterValue));
    }
  }

  excipinetidarray: any = [];
  onSelection(event, i) {
    // this.addFormproto.value.rowsapiproto[i].ExcipientName = event.option.value.excipientname;
    console.log(event);
    console.log(this.addFormproto.value.rowsapiproto);

    console.log(this.addFormproto.value.rowsapiproto[i]);

    this.addFormproto.value.rowsapiproto.forEach((data, index) => {
      if (i = this.addFormproto.value.rowsapiproto[index]) {
        const myForm = (<FormArray>this.addFormproto.get("rowsapiproto")).at(index);
        // console.log(myForm);

        myForm.patchValue({
          ExcipientId: event.option.value.excipient_id,
          // ExcipientId: event.option.value.excipient_id,
          // ExcipientName: event.option.value.excipientname
        })
      }
    });
    // this.excipinentname = event.option.value.excipientname
    // this.addFormproto.value.rowsapiproto[i].value.ExcipientName = event.option.value.excipientname;

    this.filteredOptions = null;

  }

  displayFn(user?: any): string | undefined {
    console.log(user);
    return user ? user.excipientname : undefined;
  }
  displayFnapi(user?: any): string | undefined {
    console.log(user);
    return user ? user.excipientname : undefined;
  }

  displayFnapinam(user?: any): string | undefined {
    console.log(user);
    return user ? user.excipientname : undefined;
  }
  projectID: any;
  projectcode: any;

  changeslectproject(event) {
    console.log(event);
    this.projectID = event.value.project_id
    this.projectcode = event.value.projectcode
  }
  payloadcontent: boolean = false;
  projectgrouppayload: any;
  submit: boolean;
  checkexcipinentid: boolean;
  // wtfractionvalidmsg: any;
  wtfractvalidsec: boolean = false;
  wtfracempty: boolean;
  sumvalue: any;
  sampleexcip: boolean;
  getfalsewtfractPname: any = []
  formsubmit() {

    console.log(this.empForm.value.employees);

    console.log(this.addFormproto.value.rowsapiproto);

    var mainrowproto = []
    var arraycheckexcip = []
    for (var i = 0; i < this.addFormproto.value.rowsapiproto.length; i++) {
      console.log(this.addFormproto.value.rowsapiproto[i]);


      let json = {
        "Excipicientid": this.addFormproto.value.rowsapiproto[i].ExcipientName.excipient_id,
        "weightfraction": this.addFormproto.value.rowsapiproto[i].Wtfraction
      }

      mainrowproto.push(json)
    }


    console.log(mainrowproto);

    // var temp = mainrowproto.filter(word => word.Excipicientid == undefined);
    // console.log(temp);

    console.log(this.projectcode + "_" + this.prototyperadiobtn + "_" + this.PrototypeJobSubmission.value.jobname + "_" + this.PrototypeJobSubmission.value.temperature + "C" + "_" + this.PrototypeJobSubmission.value.RH + "RH");
    this.projectgrouppayload = this.projectcode + "_" + this.prototyperadiobtn + "_" + this.PrototypeJobSubmission.value.jobname + "_" + this.PrototypeJobSubmission.value.temperature + "C" + "_" + this.PrototypeJobSubmission.value.RH + "RH";



    if (this.createprojectGroup.valid && this.createprojectGroup.value.Jobdescription.trim() != "") {
      // prototype section validation
      this.wtfractvalidsec = false;
      if (this.PrototypeJobSubmission.valid && this.PrototypeJobSubmission.value.jobname.trim() != ""
        && this.PrototypeJobSubmission.value.temperature.trim() != "" && this.PrototypeJobSubmission.value.RH.trim() != "") {
        console.log("validation");
        // prototype radiobtn 


        if (this.prototyperadiobtn == "SP") {


          if (this.empForm.value.employees.length != 0) {
            if (this.addFormproto.value.rowsapiproto.length != 0) {

              this.wtfractvalidsec = false;
              var numbers = this.addFormproto.value.rowsapiproto
              this.arraynumbers = []

              console.log(numbers);


              var isexcipinent: boolean;
              var validarrayexcipinent = numbers.every(x => x.ExcipientName != "")
              console.log(validarrayexcipinent);

              if (validarrayexcipinent == true) {
                // for (let x of numbers) {
                // if (x.ExcipientName != "") {
                isexcipinent = true

                var validarraywtfraction = mainrowproto.every(x => x.weightfraction.trim() != "")
                console.log(validarraywtfraction);

                // } else {
                //   isexcipinent = false
                //   const options = { opacity: 1, timeOut: 2000, tapToDismiss: true };
                //   this.toastrService.warning('', "Excipient Name should not be empty", options);
                // }

                // }


                // if (isexcipinent == true) {
                if (validarraywtfraction == true) {
                  this.wtfracempty = true
                  for (let x of numbers) {

                    // if (x.Wtfraction.trim() != "") {

                    this.arraynumbers.push(parseFloat(x.Wtfraction))



                  }
                } else {
                  this.wtfracempty = false
                }
              } else {
                this.wtfracempty = false
              }

              // }


              if (validarraywtfraction == false) {
                const options = { opacity: 1, timeOut: 2000, tapToDismiss: true };
                this.toastrService.warning('', "Wtfraction should not be empty", options);
              }
              // if (this.wtfracempty == false) {
              //   const options = { opacity: 1, timeOut: 2000, tapToDismiss: true };
              //   this.toastrService.warning('', "Wtfraction should not be empty", options);
              // }
              if (validarrayexcipinent == false) {
                const options = { opacity: 1, timeOut: 2000, tapToDismiss: true };
                this.toastrService.warning('', "Excipient Name should not be empty", options);
              }
              if (this.wtfracempty == true) {
                console.log(this.arraynumbers);

                var sum = 0;
                // let total = this.arraynumbers.reduce(function (curr, prev) { return curr + prev; });

                // console.log(total);
                this.arraynumbers.forEach(x => {
                  if (x != null && x != "NaN") {
                    sum += x;
                  }
                });
                console.log(sum);

                // console.log(sum.toFixed());
                this.sumvalue = sum.toFixed(4)
                console.log("sumvalue--------" + this.sumvalue);
                if (this.sumvalue == 1) {

                  this.wtfractvalidsec = false;
                  // for (let i of this.rowsapiproto.value) {
                  //   if (i.ExcipientName != "") {


                  //   } else {
                  //     this.payloadcontent = false;

                  //     const options = { opacity: 1, timeOut: 2000, tapToDismiss: true };
                  //     this.toastrService.warning('', "Excipient name should not be empty ", options);
                  //   }
                  // }
                  var temp = mainrowproto.filter(word => word.Excipicientid == undefined);

                  var arraycheckexcip = []

                  for (var i = 0; i < this.addFormproto.value.rowsapiproto.length; i++) {
                    console.log(this.addFormproto.value.rowsapiproto[i]);

                    if (this.addFormproto.value.rowsapiproto[i].ExcipientName.excipient_id == undefined) {
                      let json = {
                        "ExcipientName": this.addFormproto.value.rowsapiproto[i].ExcipientName

                      }

                      arraycheckexcip.push(json)
                    }



                    // if (this.checkidarraay.length == 0) {
                    //   this.checkidarraay.push(this.addFormproto.value.rowsapiproto[i].ExcipientName.excipient_id)

                    //   console.log(this.checkidarraay);


                    // } else {
                    //   const check = this.checkidarraay.includes(this.addFormproto.value.rowsapiproto[i].ExcipientName.excipient_id)
                    //   console.log(check);
                    //   if (!check) {
                    //     this.checkidarraay.push(this.addFormproto.value.rowsapiproto[i].ExcipientName.excipient_id)
                    //     console.log(this.checkidarraay);
                    //   }

                    //   console.log(this.addFormproto.value.rowsapiproto[i].ExcipientName.excipient_id);
                    // }

                  }
                  console.log(this.checkidarraay);

                  var teporary = []
                  for (let i of arraycheckexcip) {
                    teporary.push(i.ExcipientName)
                  }
                  console.log(arraycheckexcip);

                  var validmsgexcipnames = teporary.toString()
                  console.log(teporary);

                  // var tempvalidexciname = this.addFormproto.value.rowsapiproto.filter(word => word.ExcipientName.excipient_id != "");
                  // console.log(tempvalidexciname);

                  console.log(temp)
                  if (temp.length == 0) {
                    this.checkexcipinentid = true
                  } else {
                    this.checkexcipinentid = false

                  }
                  if (this.checkexcipinentid == true) {
                    this.submit = true;
                    this.checkexcipinentid = false
                    this.payloadcontent = true;
                  } else {
                    this.submit = false;
                    this.payloadcontent = false;
                    const options = { opacity: 1, timeOut: 2000, tapToDismiss: true };
                    this.toastrService.warning('', validmsgexcipnames + " is invalid excipient name", options);

                  }
                  if (this.submit == true) {

                    // checking if DEM file array has lengthF



                    var isapinamecheck: boolean = false
                    var checkideaual: boolean = false;
                    this.checkidarraay = []
                    var id = []
                    for (let r of this.empForm.value.employees) {

                      if (r.api_name != null && r.api_name.excipient_id) {
                        this.checkidarraay.push(r.api_name.excipient_id)

                      } else {
                        isapinamecheck = false
                        const options = { opacity: 1, timeOut: 2000, tapToDismiss: true };
                        this.toastrService.warning('', "Need API properties name", options);
                      }
                    }

                    var xmainchexk: boolean = false;
                    var apiproparray = []
                    var protoexciparray = []
                    // for (var i = 0; i < this.addFormproto.value.rowsapiproto.length; i++) {
                    //   console.log(this.addFormproto.value.rowsapiproto[i]);

                    //   protoexciparray.push(this.addFormproto.value.rowsapiproto[i].ExcipientName)
                    //   for (let i of this.empForm.value.employees) {
                    //     // if ()
                    //     apiproparray.push(i.api_name)
                    //   }

                    //   // var tempxamp = this.empForm.value.employees.findIndex(x => x.api_name.excipient_id != this.addFormproto.value.rowsapiproto[i].ExcipientName.excipient_id);
                    //   var tempxamp = ages.findIndex(x => x.ExcipientName.excipient_id == 400);
                    // }


                    // ---------------------------------------------------------
                    var xddd = []
                    var ff: boolean = false;
                    for (var i = 0; i < this.empForm.value.employees.length; i++) {
                      console.log(this.empForm.value.employees[i]);

                      // protoexciparray.push(this.empForm.value.employees[i].ExcipientName)
                      for (let i of this.empForm.value.employees) {
                        // if ()
                        apiproparray.push(i.api_name)
                      }

                      // var tempxamp = this.empForm.value.employees.findIndex(x => x.api_name.excipient_id != this.addFormproto.value.rowsapiproto[i].ExcipientName.excipient_id);

                      console.log(this.empForm.value.employees[i].api_name.excipient_id);

                      var tempxamp = this.addFormproto.value.rowsapiproto.findIndex(x => x.ExcipientName.excipient_id == this.empForm.value.employees[i].api_name.excipient_id);

                      console.log(tempxamp);


                      if (tempxamp == -1) {


                        console.log(this.empForm.value.employees[i].api_name.excipientname);
                        isapinamecheck = false
                        console.log("false");

                        xddd.push(this.empForm.value.employees[i].api_name.excipientname)
                        ff = true;
                        var notmatchexcipientnames = xddd.toString()


                      } else {

                      }


                    }

                    if (ff) {
                      console.log("ff false");

                      isapinamecheck = false
                      const options = { opacity: 1, timeOut: 2000, tapToDismiss: true };
                      this.toastrService.warning('', "Add" + " " + notmatchexcipientnames + " " + "API name on prototype job submission", options);

                    } else {
                      console.log("true");

                      xmainchexk = true
                      isapinamecheck = true
                    }



                    // if (tempxamp.length > 0) {
                    //   xmainchexk = false
                    //   isapinamecheck = false

                    //   var subsrrayxamp = []
                    //   for (let xy of tempxamp) {
                    //     xy.api_name.excipientname
                    //     subsrrayxamp.push(xy.api_name.excipientname)
                    //   }

                    //   var notmatchnames = subsrrayxamp.toString()
                    //   console.log(notmatchnames);


                    //   const options = { opacity: 1, timeOut: 2000, tapToDismiss: true };
                    //   this.toastrService.warning('', notmatchnames + " " + "API name not added with prototype excipient list", options);

                    // } else {
                    //   console.log("true");

                    //   xmainchexk = true
                    //   isapinamecheck = true


                    // }


                    // -----------------------------------------------------------------------------
                    // if (xmainchexk) {
                    //   isapinamecheck = true

                    // } else {
                    //   const options = { opacity: 1, timeOut: 2000, tapToDismiss: true };
                    //   this.toastrService.warning('', "Excipinet not matched with API propertiews", options);
                    // }
                    // const checkkkkk = this.checkidarraay.includes(id)
                    // console.log(checkkkkk);

                    if (this.temparray == 0) {
                      console.log("no need DMfiles");

                      console.log(this.rows.value);
                      console.log("submitform");

                      // this empForm is main formarray group for API properties
                      console.log("valicheck--------------------", this.empForm);

                      console.log("vali--------------------", this.empForm.valid);
                      console.log("valicheck--------------------", this.empForm);



                      if (isapinamecheck) {
                        console.log("submited");

                        var payloadAPI = {
                          // "Project_id": this.createprojectGroup.value.Project,
                          "Project_id": this.projectID,
                          "Prototypeid": this.createprojectGroup.value.Prototype,
                          // "Prototypeid": this.createprojectGroup.value.Prototype,
                          "JobDescription": this.createprojectGroup.value.Jobdescription,
                          // "Jobname": this.PrototypeJobSubmission.value.jobname,
                          "Jobname": this.projectgrouppayload,
                          // "StartDateTime": "2023-04-29T18:00:00",
                          "StartDateTime": this.paloaddate,
                          "Temp": parseFloat(this.PrototypeJobSubmission.value.temperature),
                          "RH": this.PrototypeJobSubmission.value.RH,
                          "Excipicient": mainrowproto,
                          "API_Information": this.empForm.value.employees,


                        }

                        // -------------------------newAPI------
                        this.loading = true

                        this._AdminService.createjobwithAPI(payloadAPI)
                          .pipe(first())
                          .subscribe((res: any) => {
                            if (!res.error) {
                              this.loading = false
                              console.log(res);
                              const options = { opacity: 1, timeOut: 2000, tapToDismiss: true };
                              this.toastrService.success('', res.responseMessage, options);
                              this.router.navigate(['/jobstatus']);
                            }
                            else {
                              this.loading = false
                              const options = { opacity: 1, timeOut: 2000, tapToDismiss: true };
                              this.toastrService.warning('', res.errorMessage, options);


                            }
                          },
                            err => {
                              const options = { opacity: 1, timeOut: 2000, tapToDismiss: true };
                              console.log(err);

                            });


                      }




                      // this.loading = true
                      // -------------------------oldAPI------
                      // this._AdminService.createjob(payload)
                      //   .pipe(first())
                      //   .subscribe((res: any) => {
                      //     if (!res.error) {
                      //       this.loading = false
                      //       console.log(res);
                      //       const options = { opacity: 1, timeOut: 2000, tapToDismiss: true };
                      //       this.toastrService.success('', res.responseMessage, options);
                      //       this.router.navigate(['/jobstatus']);
                      //     }
                      //     else {
                      //       this.loading = false
                      //       const options = { opacity: 1, timeOut: 2000, tapToDismiss: true };
                      //       this.toastrService.warning('', res.errorMessage, options);


                      //     }
                      //   },
                      //     err => {
                      //       const options = { opacity: 1, timeOut: 2000, tapToDismiss: true };
                      //       console.log(err);

                      //     });




                    } else {
                      console.log(" need DMfiles");

                      // if (this.temparray.length > 0) {
                      console.log("success");
                      const temp = this.temparray.flat()
                      var samplearray = []
                      for (let xaxis of temp) {

                        let json = {
                          "molecule_name": xaxis.excipientname,
                          "smiles_notation": xaxis.smiles,
                          "charge": xaxis.charge
                        }
                        samplearray.push(json)
                      }
                      console.log(this.empForm.value.employees);
                      // var APIinformation = []
                      // let apiformat = {
                      //   "API_Information": this.empForm.value.employees,
                      // }
                      // APIinformation.push(apiformat)
                      // console.log(APIinformation);

                      if (isapinamecheck) {
                        console.log("submited");


                        var payloadddddAPI = {
                          // "Project_id": this.createprojectGroup.value.Project,
                          "Project_id": this.projectID,

                          "Prototypeid": this.createprojectGroup.value.Prototype,
                          // "Prototypeid": this.createprojectGroup.value.Prototype,
                          "JobDescription": this.createprojectGroup.value.Jobdescription,
                          // "Jobname": this.PrototypeJobSubmission.value.jobname,
                          "Jobname": this.projectgrouppayload,
                          // "StartDateTime": "2023-04-29T18:00:00",
                          "StartDateTime": this.paloaddate,
                          "Temp": parseFloat(this.PrototypeJobSubmission.value.temperature),
                          "RH": this.PrototypeJobSubmission.value.RH,
                          "Excipicient": mainrowproto,
                          "DEMfiles_list": samplearray,
                          "API_Information": this.empForm.value.employees,
                        }


                        // -------------------------newAPI------
                        this.loading = true

                        this._AdminService.createjobwithAPI(payloadddddAPI)
                          .pipe(first())
                          .subscribe((res: any) => {
                            if (!res.error) {
                              this.loading = false
                              console.log(res);
                              const options = { opacity: 1, timeOut: 2000, tapToDismiss: true };
                              this.toastrService.success('', res.responseMessage, options);
                              this.router.navigate(['/jobstatus']);
                            }
                            else {
                              this.loading = false
                              const options = { opacity: 1, timeOut: 2000, tapToDismiss: true };
                              this.toastrService.warning('', res.errorMessage, options);


                            }
                          },
                            err => {
                              const options = { opacity: 1, timeOut: 2000, tapToDismiss: true };
                              console.log(err);

                            });
                      }


                      // this.loading = true
                      // -------------------------oldAPI------
                      // this._AdminService.createjob(payloaddddd)
                      //   .pipe(first())
                      //   .subscribe((res: any) => {
                      //     if (!res.error) {
                      //       this.loading = false
                      //       console.log(res);
                      //       const options = { opacity: 1, timeOut: 2000, tapToDismiss: true };
                      //       this.toastrService.success('', res.responseMessage, options);
                      //       this.router.navigate(['/jobstatus']);
                      //     }
                      //     else {
                      //       this.loading = false
                      //       const options = { opacity: 1, timeOut: 2000, tapToDismiss: true };
                      //       this.toastrService.warning('', res.errorMessage, options);


                      //     }
                      //   },
                      //     err => {
                      //       const options = { opacity: 1, timeOut: 2000, tapToDismiss: true };
                      //       console.log(err);

                      //     });
                      // -------------------------newAPI------
                      // this._AdminService.createjobwithAPI(payloaddddd)
                      //   .pipe(first())
                      //   .subscribe((res: any) => {
                      //     if (!res.error) {
                      //       this.loading = false
                      //       console.log(res);
                      //       const options = { opacity: 1, timeOut: 2000, tapToDismiss: true };
                      //       this.toastrService.success('', res.responseMessage, options);
                      //       // this.router.navigate(['/jobstatus']);
                      //     }
                      //     else {
                      //       this.loading = false
                      //       const options = { opacity: 1, timeOut: 2000, tapToDismiss: true };
                      //       this.toastrService.warning('', res.errorMessage, options);


                      //     }
                      //   },
                      //     err => {
                      //       const options = { opacity: 1, timeOut: 2000, tapToDismiss: true };
                      //       console.log(err);

                      //     });

                    }

                  }
                } else {
                  this.payloadcontent = false;
                  this.wtfractvalidsec = true;
                  // this.wtfractionvalidmsg = "Sum of Wt.fraction must be equal to one"
                  const options = { opacity: 1, timeOut: 2000, tapToDismiss: true };
                  this.toastrService.warning('', "Sum of Wt.fraction must be equal to one", options);
                }
              }



            } else {
              const options = { opacity: 1, timeOut: 2000, tapToDismiss: true };
              this.toastrService.warning('', "Excipient values was empty", options);
            }
          } else {
            const options = { opacity: 1, timeOut: 2000, tapToDismiss: true };
            this.toastrService.warning('', "Add API properties", options);
          }




        }


        if (this.prototyperadiobtn == "MP") {
          console.log("multiupload");
          console.log(this.uploadedfileres);

          if (this.storefile != undefined) {


            var xddddddd = []
            // var checkAPiprops: boolean = false;
            var chesckequalexcipe: boolean = false;

            for (let r of this.empForm.value.employees) {
              console.log(r);

              if (r.api_name != null && r.api_name.excipient_id) {
                // this.checkidarraay.push(r.api_name.excipient_id)
                this.checkAPiprops = true
              } else {
                this.checkAPiprops = false
                const options = { opacity: 1, timeOut: 2000, tapToDismiss: true };
                this.toastrService.warning('', "Need API properties name", options);
              }
            }


            if (this.checkAPiprops == false) {
              console.log(" false");

              // const options = { opacity: 1, timeOut: 2000, tapToDismiss: true };
              // this.toastrService.warning('', "Add" + " " + notmatchexcipientnames + " " + "API name on CSV file", options);

            } else {
              console.log(" true");

              for (var i = 0; i < this.empForm.value.employees.length; i++) {
                var tempxamp = this.uploadedfileres.moleculesjoblist.findIndex(x => x.moleculeid == this.empForm.value.employees[i].api_name.excipient_id);

                console.log(tempxamp);

                if (tempxamp == -1) {
                  console.log(this.empForm.value.employees[i].api_name.excipientname);
                  // isapinamecheck = false
                  console.log("false");
                  xddddddd.push(this.empForm.value.employees[i].api_name.excipientname)
                  var notmatchexcipientnames = xddddddd.toString()
                  chesckequalexcipe = true;

                } else {

                  chesckequalexcipe = false

                  const checkisavailableexcip = this.uploadedfileres.moleculesjoblist.every((x) => x.isavailable == true)


                  if (checkisavailableexcip) {

                    // const checkispublish = this.uploadedfileres.every((x) => x.ispublished == true)
                    // if (checkispublish == true) {
                    console.log("no need DMfiles");
                    var checknullwtfraction: boolean;
                    for (const molecule of this.uploadedfileres.moleculesjoblist) {
                      for (const prototype of molecule.prototypelist) {
                        if (prototype.wtfraction == null || prototype.wtfraction == "") {
                          console.log("wt empty");
                          checknullwtfraction = true;

                          break;
                          // wtfraction is null
                        } else {
                          console.log("wt empty false");

                          checknullwtfraction = false;
                        }
                      }
                      if (checknullwtfraction == true) {
                        console.log("break");

                        break; // Stop checking further molecules if wtfraction is empty
                      }
                    }
                    console.log(checknullwtfraction);

                    // wtfraction is not null

                    // const checknullwtfraction = this.uploadedfileres.every((x) => x.Wt_FRACTION != null)

                    if (checknullwtfraction == false) {
                      var wtfraction = []

                      console.log(this.uploadedfileres);

                      var Excipicient = []
                      // var transformedData = {
                      //   "Excipicient": []
                      // };
                      this.uploadedfileres.moleculesjoblist.forEach(molecule => {
                        molecule.prototypelist.forEach(prototype => {
                          console.log(Excipicient);

                          const existingPrototype = Excipicient.find(item => item.prototypename === prototype.prototypename);
                          console.log(existingPrototype);

                          if (existingPrototype) {
                            if (molecule.moleculeid) {
                              existingPrototype.protoypeexpList.push({
                                "Excipicientid": molecule.moleculeid,
                                "weightfraction": prototype.wtfraction
                              });
                            }
                          } else {
                            const newPrototype = {
                              "prototypename": prototype.prototypename,
                              "protoypeexpList": []
                            };
                            if (molecule.moleculeid) {
                              newPrototype.protoypeexpList.push({
                                "Excipicientid": molecule.moleculeid,
                                "weightfraction": prototype.wtfraction
                              });
                            }
                            Excipicient.push(newPrototype);
                          }
                        });
                      });
                      console.log(Excipicient);


                      const moleculenames = [];
                      this.getfalsewtfractPname = []
                      Excipicient.forEach(molecule => {
                        let sum = 0;
                        let protoname;
                        var gettempwtfraction
                        molecule.protoypeexpList.forEach(job => {
                          sum += parseFloat(job.weightfraction);
                          protoname = job.Excipicientid
                        });
                        console.log(sum);
                        gettempwtfraction = sum.toFixed(4)
                        if (gettempwtfraction != 1) {
                          console.log("notequal");

                          moleculenames.push({ protoid: protoname, sum: sum });
                          this.getfalsewtfractPname.push(molecule.prototypename)
                        }
                      });
                      console.log(moleculenames);
                      console.log(this.getfalsewtfractPname);

                      // moleculenames.forEach(x => {

                      //   this.uploadedfileres.moleculesjoblist.forEach(y => {
                      //     console.log(x);
                      //     if (x.protoid == y.moleculeid){

                      //     }
                      //   })



                      // })



                      if (moleculenames.length == 0) {
                        console.log("submited");

                        // var mainexcipientarray = []
                        // this.uploadedfileres.forEach(x => {
                        //   let json = {
                        //     "Excipicientid": x.excipientid,
                        //     "weightfraction": x.Wt_FRACTION
                        //   }
                        //   mainexcipientarray.push(json)

                        // })
                        // -----------------get excipient array-----

                        // var transformedData = {
                        //   "Excipicient": []
                        // };
                        // this.uploadedfileres.moleculesjoblist.forEach(molecule => {
                        //   molecule.prototypelist.forEach(prototype => {
                        //     console.log(transformedData.Excipicient);

                        //     const existingPrototype = transformedData.Excipicient.find(item => item.prototypename === prototype.prototypename);
                        //     console.log(existingPrototype);

                        //     if (existingPrototype) {
                        //       if (molecule.moleculeid) {
                        //         existingPrototype.protoypeexpList.push({
                        //           "Excipicientid": molecule.moleculeid,
                        //           "weightfraction": prototype.wtfraction
                        //         });
                        //       }
                        //     } else {
                        //       const newPrototype = {
                        //         "prototypename": prototype.prototypename,
                        //         "protoypeexpList": []
                        //       };
                        //       if (molecule.moleculeid) {
                        //         newPrototype.protoypeexpList.push({
                        //           "Excipicientid": molecule.moleculeid,
                        //           "weightfraction": prototype.wtfraction
                        //         });
                        //       }
                        //       transformedData.Excipicient.push(newPrototype);
                        //     }
                        //   });
                        // });
                        // console.log(transformedData);

                        var payloadAPImulti = {
                          // "Project_id": this.createprojectGroup.value.Project,
                          "Project_id": this.projectID,
                          "Prototypeid": this.createprojectGroup.value.Prototype,
                          // "Prototypeid": this.createprojectGroup.value.Prototype,
                          "JobDescription": this.createprojectGroup.value.Jobdescription,
                          // "Jobname": this.PrototypeJobSubmission.value.jobname,
                          "Jobname": this.projectgrouppayload,
                          // "StartDateTime": "2023-04-29T18:00:00",
                          "StartDateTime": this.paloaddate,
                          "Temp": parseFloat(this.PrototypeJobSubmission.value.temperature),
                          "RH": this.PrototypeJobSubmission.value.RH,
                          "Excipicient": Excipicient,
                          "API_Information": this.empForm.value.employees,
                        }

                        console.log(payloadAPImulti);

                        // // -------------------------newAPI------
                        this.loading = true

                        this._AdminService.createjobmulti(payloadAPImulti)
                          .pipe(first())
                          .subscribe((res: any) => {
                            if (!res.error) {
                              this.loading = false
                              console.log(res);
                              const options = { opacity: 1, timeOut: 2000, tapToDismiss: true };
                              this.toastrService.success('', res.responseMessage, options);
                              this.router.navigate(['/jobstatus']);
                            }
                            else {
                              this.loading = false
                              const options = { opacity: 1, timeOut: 2000, tapToDismiss: true };
                              this.toastrService.warning('', res.errorMessage, options);
                            }
                          },
                            err => {
                              const options = { opacity: 1, timeOut: 2000, tapToDismiss: true };
                              console.log(err);

                            });

                      } else {
                        var samplestring = this.getfalsewtfractPname.toString()
                        this.getfalsewtfractPname
                        const options = { opacity: 1, timeOut: 2000, tapToDismiss: true };
                        this.toastrService.warning('', "For" + " " + samplestring + " " + "The sum of wt.fraction must be equal to one", options);
                      }


                    } else {
                      const options = { opacity: 1, timeOut: 2000, tapToDismiss: true };
                      this.toastrService.warning('', "Wtfraction should not be empty", options);

                    }
                    // } 

                    // else {
                    //   if (this.temparray == 0) {

                    //     var getfalsepublish = []
                    //     this.uploadedfileres.forEach(x => {
                    //       if (x.ispublished == false) {
                    //         getfalsepublish.push(x.excipientname)
                    //       }
                    //     })

                    //     var falseexcipstring = getfalsepublish.toString()
                    //     const options = { opacity: 1, timeOut: 2000, tapToDismiss: true };
                    //     this.toastrService.warning('', " Create molecule for" + " " + falseexcipstring, options);

                    //   } else {
                    //     console.log("need DMfiles");

                    //     const checknullwtfraction = this.uploadedfileres.every((x) => x.Wt_FRACTION != null)

                    //     if (checknullwtfraction == true) {
                    //       var wtfraction = []

                    //       for (let i of this.uploadedfileres) {
                    //         if (i.Wt_FRACTION != null) {
                    //           wtfraction.push(parseFloat(i.Wt_FRACTION))
                    //         }
                    //       }
                    //       console.log(wtfraction);
                    //       var sum = 0;
                    //       wtfraction.forEach(x => {

                    //         if (x != null && x != "NaN") {
                    //           sum += x;
                    //         }
                    //       });
                    //       console.log(sum);

                    //       // console.log(sum.toFixed());
                    //       this.sumvalue = sum.toFixed(4)
                    //       console.log(this.sumvalue);


                    //       if (this.sumvalue == 1) {
                    //         console.log("submited");

                    //         var mainexcipientarray = []
                    //         this.uploadedfileres.forEach(x => {
                    //           let json = {
                    //             "Excipicientid": x.excipientid,
                    //             "weightfraction": x.Wt_FRACTION
                    //           }
                    //           mainexcipientarray.push(json)

                    //         })


                    //         console.log("success");
                    //         const temp = this.temparray.flat()
                    //         var samplearray = []
                    //         for (let xaxis of temp) {

                    //           let json = {
                    //             "molecule_name": xaxis.excipientname,
                    //             "smiles_notation": xaxis.smiles,
                    //             "charge": xaxis.charge
                    //           }
                    //           samplearray.push(json)
                    //         }
                    //         console.log(this.empForm.value.employees);

                    //         console.log("submited");




                    //         // var payloadAPI = {
                    //         //   // "Project_id": this.createprojectGroup.value.Project,
                    //         //   "Project_id": this.projectID,
                    //         //   "Prototypeid": this.createprojectGroup.value.Prototype,
                    //         //   // "Prototypeid": this.createprojectGroup.value.Prototype,
                    //         //   "JobDescription": this.createprojectGroup.value.Jobdescription,
                    //         //   // "Jobname": this.PrototypeJobSubmission.value.jobname,
                    //         //   "Jobname": this.projectgrouppayload,
                    //         //   // "StartDateTime": "2023-04-29T18:00:00",
                    //         //   "StartDateTime": this.paloaddate,
                    //         //   "Temp": parseFloat(this.PrototypeJobSubmission.value.temperature),
                    //         //   "RH": this.PrototypeJobSubmission.value.RH,
                    //         //   "Excipicient": mainexcipientarray,
                    //         //   "API_Information": this.empForm.value.employees,


                    //         // }


                    //         var payloadddddAPI = {
                    //           // "Project_id": this.createprojectGroup.value.Project,
                    //           "Project_id": this.projectID,

                    //           "Prototypeid": this.createprojectGroup.value.Prototype,
                    //           // "Prototypeid": this.createprojectGroup.value.Prototype,
                    //           "JobDescription": this.createprojectGroup.value.Jobdescription,
                    //           // "Jobname": this.PrototypeJobSubmission.value.jobname,
                    //           "Jobname": this.projectgrouppayload,
                    //           // "StartDateTime": "2023-04-29T18:00:00",
                    //           "StartDateTime": this.paloaddate,
                    //           "Temp": parseFloat(this.PrototypeJobSubmission.value.temperature),
                    //           "RH": this.PrototypeJobSubmission.value.RH,
                    //           "Excipicient": mainexcipientarray,
                    //           "DEMfiles_list": samplearray,
                    //           "API_Information": this.empForm.value.employees,
                    //         }

                    //         console.log(payloadddddAPI);

                    //         // // -------------------------newAPI------
                    //         this._AdminService.createjobwithAPI(payloadddddAPI)
                    //           .pipe(first())
                    //           .subscribe((res: any) => {
                    //             if (!res.error) {
                    //               this.loading = false
                    //               console.log(res);
                    //               const options = { opacity: 1, timeOut: 2000, tapToDismiss: true };
                    //               this.toastrService.success('', res.responseMessage, options);
                    //               this.router.navigate(['/jobstatus']);
                    //             }
                    //             else {
                    //               this.loading = false
                    //               const options = { opacity: 1, timeOut: 2000, tapToDismiss: true };
                    //               this.toastrService.warning('', res.errorMessage, options);


                    //             }
                    //           },
                    //             err => {
                    //               const options = { opacity: 1, timeOut: 2000, tapToDismiss: true };
                    //               console.log(err);

                    //             });

                    //       } else {
                    //         // this.payloadcontent = false;
                    //         // this.wtfractvalidsec = true;
                    //         // this.wtfractionvalidmsg = "Sum of Wt.fraction must be equal to one"
                    //         const options = { opacity: 1, timeOut: 2000, tapToDismiss: true };
                    //         this.toastrService.warning('', "Sum of Wt.fraction must be equal to one", options);
                    //       }


                    //     } else {
                    //       const options = { opacity: 1, timeOut: 2000, tapToDismiss: true };
                    //       this.toastrService.warning('', "Wtfraction should not be empty", options);

                    //     }

                    //   }

                    // }






                  } else {
                    var getfalseexcip = []
                    this.uploadedfileres.moleculesjoblist.forEach(x => {
                      if (x.isavailable == false) {
                        getfalseexcip.push(x.moleculename)
                      }
                    })

                    var falseexcipstring = getfalseexcip.toString()
                    const options = { opacity: 1, timeOut: 2000, tapToDismiss: true };
                    this.toastrService.warning('', falseexcipstring + " " + "excipient not available", options);

                  }

                }
              }

            }

            if (chesckequalexcipe == true) {

              const options = { opacity: 1, timeOut: 2000, tapToDismiss: true };
              this.toastrService.warning('', "Add" + " " + notmatchexcipientnames + " " + "API name on CSV file", options);

            }
          } else {
            const options = { opacity: 1, timeOut: 2000, tapToDismiss: true };
            this.toastrService.warning('', "Please upload file", options);
          }

        }


      } else {
        this.payloadcontent = false;
        const options = { opacity: 1, timeOut: 2000, tapToDismiss: true };
        this.toastrService.warning('', "Please enter prototype job submission fields", options);
      }
    }
    else {
      this.payloadcontent = false;
      const options = { opacity: 1, timeOut: 2000, tapToDismiss: true };
      this.toastrService.warning('', "Please enter project fields", options);
    }
  }
  checkAPiprops: boolean = false;
  uploadexcipvalimsg: boolean = false;
  falseexcipsrray: any;
  tableloop: any;
  add() {
    this.containers.push(this.containers.length);

    console.log(this.containers);
  }

  createsamplegroup(): FormGroup {
    return this.fbsample.group({
      Name: null,
      temp: null,
      value: null
    });
  }


  logout() {
    this.authenticationService.logout();
    this.router.navigate(['']);
  }
  savemoleculesbtn: boolean = true;
  savemoleculesbtnhide: boolean = false;
  issavebtnvalid: boolean = false;
  disablefield: boolean = true;
  isReadonly = false;
  temparray: any = [];
  moleculedeleicon: boolean = true;
  storagearray: any = [];


  savemolecules(rowIndex) {

    var temparraysample = []
    for (let z of this.rows.value) {

      if (z.isdelete == true) {
        var rowsvaluelooped = {
          "excipientname": z.excipientname,
          "smiles": z.smiles,
          "charge": z.charge
        }

        temparraysample.push(rowsvaluelooped)
      }

      // z.isdelete = false
      // z.readonly = true
      if (z.excipientname != null) {
        if (z.excipientname.trim() != "") {
          if (z.smiles != null) {

            if (z.smiles.trim() != "") {
              if (z.charge != null) {
                if (z.charge.trim() != "") {
                  this.issavebtnvalid = true;

                } else {
                  this.issavebtnvalid = false;
                  const options = { opacity: 1, timeOut: 2000, tapToDismiss: true };
                  this.toastrService.warning('', "Charge should not be empty", options);
                }


              } else {
                const options = { opacity: 1, timeOut: 2000, tapToDismiss: true };
                this.toastrService.warning('', "Charge should not be empty", options);
                console.log("array has NULL charge");
                this.issavebtnvalid = false;
              }

            } else {
              this.issavebtnvalid = false;
              const options = { opacity: 1, timeOut: 2000, tapToDismiss: true };
              this.toastrService.warning('', "Smiles should not be empty", options);
            }

          } else {
            const options = { opacity: 1, timeOut: 2000, tapToDismiss: true };
            this.toastrService.warning('', "Smiles should not be empty", options);
            console.log("array has NULL smiles");
            this.issavebtnvalid = false;
          }
        } else {
          this.issavebtnvalid = false;
          const options = { opacity: 1, timeOut: 2000, tapToDismiss: true };
          this.toastrService.warning('', "Molecule name should not be empty", options);
        }


      } else {
        console.log("array has NULL Molecule name");
        const options = { opacity: 1, timeOut: 2000, tapToDismiss: true };
        this.toastrService.warning('', "Molecule name should not be empty", options);
        this.issavebtnvalid = false;

      }

    }
    console.log(temparraysample);
    console.log(this.rows.value);


    if (this.issavebtnvalid == true) {

      if (temparraysample.length != 0) {
        const dialogRef = this.dialog.open(JobcreationSavemoleculesComponent, {
          width: '100%',
          data: this.rows.value,
          panelClass: 'savemolecules',
        });
        dialogRef.afterClosed().subscribe(result => {
          if (result) {
            if (result.data) {
              console.log(result.data)

              var jsonpaylod = {
                "DMfiles": temparraysample
              }

              console.log(jsonpaylod);

              this.loading = true
              this._AdminService.savemolecules(jsonpaylod)
                .pipe(first())
                .subscribe((res: any) => {
                  if (!res.error) {
                    this.loading = false
                    this.moleculedeleicon = false;
                    const options = { opacity: 1, timeOut: 2000, tapToDismiss: true };
                    this.toastrService.success('', res.responseMessage, options);
                    for (let y of this.rows.value) {
                      y.isdelete = false
                      y.readonly = true
                    }
                    console.log(this.rows.value);

                    this.temparray.push(temparraysample)
                    console.log("temp-------------" + JSON.stringify(this.temparray));
                    console.log("temp---flat----------" + JSON.stringify(this.temparray.flat()));

                  }
                  else {
                    this.loading = false
                    const options = { opacity: 1, timeOut: 2000, tapToDismiss: true };
                    this.toastrService.warning('', res.errorMessage, options);

                  }
                },
                  err => {
                    const options = { opacity: 1, timeOut: 2000, tapToDismiss: true };
                    console.log(err);

                  });


            } else {
              this.loading = false
              const options = { opacity: 1, timeOut: 2000, tapToDismiss: true };
              this.toastrService.warning('', result.data.errorMessage, options);
            }
          }
        },
          err => {
            const options = { opacity: 1, timeOut: 2000, tapToDismiss: true };
            this.toastrService.warning('', err.error, options);
          });
      } else {
        const options = { opacity: 1, timeOut: 2000, tapToDismiss: true };
        this.toastrService.warning('', "Click add to add molecules", options);
      }


    }



  }

  // --------------------------Formdem API information--------------------------
  indexid: any;
  patientControlapi = new FormControl();
  patientControlapiname = new FormControl();

  employees(): FormArray {
    return this.empForm.get('employees') as FormArray;
  }

  newEmployee(): FormGroup {
    return this.fb.group({
      api_name: null,
      mp: null,
      hfus: null,
      api_solubility: this.fb.array([])
    });
  }

  addEmployee() {
    this.employees().push(this.newEmployee());
    console.log("wwdwwsnvkjsnn");
    if (this.empForm.value.employees.length == 1) {
      console.log("length-----------1");

      this.addEmployeeSkill(0)
    }
    // else {
    //   console.log("else-----------",this.indexid);

    //   this.addEmployeeSkill(this.indexid)
    // }

    console.log(this.empForm.value.employees);

  }

  removeEmployee(empIndex: number) {
    this.employees().removeAt(empIndex);
  }

  employeeSkills(empIndex: number): FormArray {
    return this.employees()
      .at(empIndex)
      .get('api_solubility') as FormArray;
  }

  newSkill(): FormGroup {
    return this.fb.group({
      solvent_id: null,
      temp: null,
      value: null,
    });
  }

  addEmployeeSkill(empIndex: number) {
    // console.log("empindex");
    // this.indexid = empIndex
    this.employeeSkills(empIndex).push(this.newSkill());
    console.log(this.empForm.value.employees);

  }

  removeEmployeeSkill(empIndex: number, skillIndex: number) {
    this.employeeSkills(empIndex).removeAt(skillIndex);
  }

  onSubmit() {
    console.log(this.empForm.value);
  }



  getDropdownapi(event) {
    console.log(event.target.value);
    console.log(this.addFormproto.value.rowsapiproto);
    for (let i of this.addFormproto.value.rowsapiproto) {
      // if (i.ExcipientName.trim() != "") {
      console.log(true);
      if (event.target.value.length >= 2) {
        this.loading = true
        this._AdminService.getmoleculekeyup(event.target.value)
          .pipe(first())
          .subscribe((res: any) => {
            if (!res.isError) {
              this.loading = false
              console.log(res);
              // this.project = res.responseMessage
              console.log(this.addFormproto.value.rowsapiproto);

              this.drugArray = res.responseMessage;
              console.log(this.drugArray);
              this.molearray = res.responseMessage
              this.filteredOptionsapi = this.patientControlapi.valueChanges
                .pipe(
                  startWith(''),
                  map(value => this._filterapi(value)),

                );
              console.log(this.filteredOptionsapi)
            }
            else {
              this.loading = false
              const options = { opacity: 1, timeOut: 2000, tapToDismiss: true };
              this.toastrService.warning('', res.errorMessage, options);
              // setTimeout(() => {
              //   this.toastrService.clear(),2000
              // }, 2000);

            }
          },
            err => {
              const options = { opacity: 1, timeOut: 2000, tapToDismiss: true };
              console.log(err);

            });

      }
      // } else {
      //   console.log("false");
      //   const options = { opacity: 1, timeOut: 2000, tapToDismiss: true };
      //   this.toastrService.warning('', "ExcipientName should not be empty", options);
      // }
    }



    if (event.target.value.length == 0) {
      this.filteredOptionsapi = null;
    }

  }


  private _filterapi(value: string): string[] {
    const filterValue = value;
    console.log(filterValue);

    if (this.drugArray) {
      return this.drugArray.filter(option => option.excipientname.toLowerCase().includes(filterValue));
    }
  }


  onSelectionapi(event, i) {
    // this.addFormproto.value.rowsapiproto[i].ExcipientName = event.option.value.excipientname;
    console.log(event, i);
    console.log(this.empForm.value.employees[i]);
    // console.log(this.addFormproto.value.rowsapiproto);

    // console.log(this.addFormproto.value.rowsapiproto[i]);

    // this.empForm.value.employees.forEach((data, index) => {
    //   if (i = this.empForm.value.employees[index]) {
    //     const myForm = (<FormArray>this.empForm.get("employees")).at(index);
    //     // console.log(myForm);

    //     myForm.patchValue({
    //       api_name: event.option.value.excipientname,
    //       api_id: event.option.value.excipient_id,
    //       // ExcipientId: event.option.value.excipient_id,
    //       // ExcipientName: event.option.value.excipientname
    //     })
    //   }
    // });


    // this.excipinentname = event.option.value.excipientname
    // this.addFormproto.value.rowsapiproto[i].value.ExcipientName = event.option.value.excipientname;
    // this.empForm.value.employees[i].api_name = event.option.value.excipient_id;
    // this.empForm.value.employees[i].api_id = event.option.value.excipientname;
    console.log(this.empForm.value.employees[i]);

    this.filteredOptionsapi = null;

  }





  // -----------------------------api name--------------------

  getDropdownapiname(event) {
    console.log(event.target.value);
    console.log(this.addFormproto.value.rowsapiproto);
    for (let i of this.addFormproto.value.rowsapiproto) {
      // if (i.ExcipientName.trim() != "") {
      console.log(true);
      if (event.target.value.length >= 2) {
        this.loading = true
        this._AdminService.getmoleculekeyup(event.target.value)
          .pipe(first())
          .subscribe((res: any) => {
            if (!res.isError) {
              this.loading = false
              console.log(res);
              // this.project = res.responseMessage
              console.log(this.addFormproto.value.rowsapiproto);

              this.drugArray = res.responseMessage;
              console.log(this.drugArray);
              this.molearray = res.responseMessage
              this.filteredOptionsapiname = this.patientControlapiname.valueChanges
                .pipe(
                  startWith(''),
                  map(value => this._filterapi(value)),

                );
              console.log(this.filteredOptionsapiname)
            }
            else {
              this.loading = false
              const options = { opacity: 1, timeOut: 2000, tapToDismiss: true };
              this.toastrService.warning('', res.errorMessage, options);
              // setTimeout(() => {
              //   this.toastrService.clear(),2000
              // }, 2000);

            }
          },
            err => {
              const options = { opacity: 1, timeOut: 2000, tapToDismiss: true };
              console.log(err);

            });

      }
      // } else {
      //   console.log("false");
      //   const options = { opacity: 1, timeOut: 2000, tapToDismiss: true };
      //   this.toastrService.warning('', "ExcipientName should not be empty", options);
      // }
    }



    if (event.target.value.length == 0) {
      this.filteredOptionsapiname = null;
    }

  }


  private _filterapiname(value: string): string[] {
    const filterValue = value;
    console.log(filterValue);

    if (this.drugArray) {
      return this.drugArray.filter(option => option.excipientname.toLowerCase().includes(filterValue));
    }
  }


  onSelectionapiname(event, i, parentindex) {
    // this.addFormproto.value.rowsapiproto[i].ExcipientName = event.option.value.excipientname;
    console.log(event);
    console.log(i);

    console.log(parentindex);

    console.log(this.empForm.value.employees);

    console.log(this.empForm.value.employees[i]);

    // this.empForm.value.employees[i].skills.forEach((data, index) => {
    //   console.log(event.option.value.excipient_id);
    //   console.log(data);
    //   if (event.option.value.excipient_id) {
    //     // const myForm = (<FormArray>this.empForm.get("employees")).at(i).get('skills').at(index);
    //     // console.log(myForm);
    //     // console.log("in---------");

    //     // this.empForm.value.employees[i].skills[index].patchValue({
    //     //   solvent_id: event.option.value.excipient_id,
    //     //   // ExcipientId: event.option.value.excipient_id,
    //     //   // ExcipientName: event.option.value.excipientname
    //     // })



    //     ((this.empForm.get('employees') as FormArray)
    //       .at(parentindex).get('skills') as FormArray)
    //       .at(i).get("solvent_id").patchValue(
    //         event.option.value.excipient_id,
    //       );
    //   }
    // });


    // this.excipinentname = event.option.value.excipientname
    // this.empForm.value.employees[i].skills[i].solvent_id = event.option.value.excipient_id;

    this.filteredOptionsapiname = null;

  }


  checkarray(a, b) {
    let counter = 0;
    for (var i = 0; i < b.length; i++) {
      ;
      if (a.includes(b[i])) counter++;
    }
    if (counter === b.length) return true;
    return false;
  }
  myfilename = 'Browse your file from your computer';
  storefile: any;
  @ViewChild('UploadFileInput') uploadFileInput: ElementRef;

  fileChangeEvent(fileInput: any) {
    console.log(this.storefile);

    if (fileInput.target.files && fileInput.target.files[0]) {
      this.myfilename = '';
      Array.from(fileInput.target.files).forEach((file: File) => {
        console.log(file);
        this.storefile = file
        console.log(this.storefile)
        this.myfilename += file.name;
      });
      const reader = new FileReader();
      reader.onload = (e: any) => {
        const image = new Image();
        image.src = e.target.result;
        image.onload = rs => {          // Return Base64 Data URL
          const imgBase64Path = e.target.result;
        };
      };
      reader.readAsDataURL(fileInput.target.files[0]);      // Reset File Input to Selct Same file again
      // this.uploadFileInput.nativeElement.value = "";
    }


  }

  uploadedfileres: any;
  uploadfile() {
    console.log(this.storefile);
    console.log(this.uploadedfileres);

    const formdatafileupload: FormData = new FormData();
    formdatafileupload.append('file', this.storefile);

    if (this.storefile != undefined) {
      this.loading = true
      this._AdminService.csvupload(formdatafileupload)
        .pipe(first())
        .subscribe((res: any) => {
          if (!res.error) {
            this.loading = false
            console.log(res);
            this.uploadedfileres = res.responseMessage
            this.uploadFileInput.nativeElement.value = "";
            // this.uploadedfileres = res.data


            // ------------------------------------------------------------
            console.log(this.uploadedfileres);


            // ---------------------------------
            console.log(this.uploadedfileres);

            this.getexcipinet = []
            this.getwtfractionname = []
            this.getwtfractionvalue = []

            this.uploadedfileres.moleculeslist.forEach(x => {
              this.getexcipinet.push(x.moleculename)
            })

            console.log(this.getexcipinet);

            // ----------------------
            this.uploadedfileres.headerInformation.forEach(x => {
              this.getwtfractionname.push(x.wtfraction)
            })

            console.log(this.getwtfractionname);

            // ------------------------
            var xsamp = []
            this.uploadedfileres.moleculesjoblist.forEach((x, index) => {
              var temp = []
              console.log(index);

              x.prototypelist.forEach(y => {
                temp.push(y.wtfraction)

              })
              let json = {
                isavailable: x.isavailable,
                moleculename: x.moleculename,
                data: temp
              }
              this.getwtfractionvalue.push(json)

            })
            console.log(this.getwtfractionvalue);

            // ------------------------------------------------------------------

          }
          else {
            this.uploadFileInput.nativeElement.value = "";
            this.loading = false
            const options = { opacity: 1, timeOut: 2000, tapToDismiss: true };
            this.toastrService.warning('', res.errorMessage, options);

          }
        },
          err => {
            const options = { opacity: 1, timeOut: 2000, tapToDismiss: true };
            // this.toastrService.warning('', res.errorMessage, options);

            console.log(err);

          });
    } else {
      const options = { opacity: 1, timeOut: 2000, tapToDismiss: true };
      this.toastrService.warning('', "Please upload file", options);
    }

  }

  data: any;
  downloadexcipinetcsv() {

    this.loading = true
    this._AdminService.excipientlistcsv()
      .pipe(first())
      .subscribe((res: any) => {
        if (!res.isError) {
          this.loading = false
          console.log(res);
          const newBlob = new Blob([res], { type: 'application/csv' });
          this.data = window.URL.createObjectURL(res);
          const file_path = this.data;
          const down = document.createElement('A') as HTMLAnchorElement;
          down.href = file_path;
          down.download = "Excipient list"
          document.body.appendChild(down);
          down.click();
          document.body.removeChild(down);

        }
        else {
          this.loading = false
          const options = { opacity: 1, timeOut: 2000, tapToDismiss: true };
          this.toastrService.warning('', res.errorMessage, options);

        }
      },
        err => {
          const options = { opacity: 1, timeOut: 2000, tapToDismiss: true };
          console.log(err);

        });
  }
}
