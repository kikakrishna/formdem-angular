import { RouterModule } from "@angular/router";
import { ProjectlistComponent} from "./projectlist.component";
export const projectlistRoutes: RouterModule [] = [
    {
        path: '',
        component: ProjectlistComponent
    }
]