import { Component, OnInit, ViewChild } from '@angular/core';
import { MatTableDataSource } from '@angular/material/table';
import { FormGroup } from '@angular/forms';
import { FormBuilder, Validators, FormControl, FormArray, NgForm } from '@angular/forms';
import { MatPaginator } from '@angular/material/paginator';
// import { AdduserComponent } from '../adduser/adduser.component';
import { MatDialog } from '@angular/material/dialog';
import { AssignuserComponent } from '../assignuser/assignuser.component';
import { AddprojectComponent } from '../addproject/addproject.component';
import { EditprojectComponent } from '../editproject/editproject.component';
import { AuthenticationService } from 'src/app/_Services/authentication.service';
import { Router } from '@angular/router';
import { AdminService } from 'src/app/_Services/admin.sevice';
import { ToastService } from 'ng-uikit-pro-standard';
import { first } from 'rxjs/operators';
import * as moment from 'moment';
import { element } from 'protractor';

export interface PeriodicElement {
  // id: number;
  projectname: string;
  projectcode: string;
  sponsor: string;
  startdate: string;
  action: string;
}

const ELEMENT_DATA: PeriodicElement[] = [
  // { id: 1, projectname: 'P00-PTR-ST-01 STUDY', projectcode: 'PROJ-011', sponsor: 'Kamaraj ', startdate: '04-04-2023', action: '' },
  // { id: 2, projectname: 'P00-PTR-ST-01 STUDY', projectcode: 'PROJ-011', sponsor: 'Kamaraj ', startdate: '04-04-2023', action: '' },
  // { id: 3, projectname: 'P00-PTR-ST-01 STUDY', projectcode: 'PROJ-011', sponsor: 'Kamaraj ', startdate: '04-04-2023', action: '' },
  // { id: 4, projectname: 'P00-PTR-ST-01 STUDY', projectcode: 'PROJ-011', sponsor: 'Kamaraj ', startdate: '04-04-2023', action: '' },
  // { id: 5, projectname: 'P00-PTR-ST-01 STUDY', projectcode: 'PROJ-011', sponsor: 'Kamaraj ', startdate: '04-04-2023', action: '' },
  // { id: 6, projectname: 'P00-PTR-ST-01 STUDY', projectcode: 'PROJ-011', sponsor: 'Kamaraj ', startdate: '04-04-2023', action: '' },
  // { id: 7, projectname: 'P00-PTR-ST-01 STUDY', projectcode: 'PROJ-011', sponsor: 'Kamaraj ', startdate: '04-04-2023', action: '' },
];


@Component({
  selector: 'app-projectlist',
  templateUrl: './projectlist.component.html',
  styleUrls: ['./projectlist.component.css']
})
export class ProjectlistComponent implements OnInit {

  displayedColumns: string[] = ['projectname', 'projectcode', 'sponsor', 'startdate', 'action'];
  // dataSource = ELEMENT_DATA;
  //  public jobstatus: any = new MatTableDataSource([]);
  dataSource = new MatTableDataSource<any>([]);
  @ViewChild(MatPaginator) paginator: MatPaginator;
  @ViewChild('paginator', { static: false }) projectlistpaginator: MatPaginator;
  public filerpastform_pagination_show: boolean;
  public totalSize = 10;
  public pageSize = 10;
  public pageindex = 0;
  filterData: boolean;
  firstname: string;
  lastname: string;
  projectlist: any;
  loading: boolean;
  role: string;
  listdata: boolean;
  applyfilterData: boolean;
  Fsearchstring: any;

  constructor(public dialog: MatDialog,
    public _formBuilder: FormBuilder, public authenticationService: AuthenticationService, private router: Router
    , private _AdminService: AdminService, private toastrService: ToastService) {
    this.firstname = sessionStorage.getItem("firstname");
    this.lastname = sessionStorage.getItem("lastname");
    this.role = sessionStorage.getItem("role");
  }
  adduserGroup: FormGroup
  ngOnInit(): void {

    if (this.role != "Manager") {
      this.displayedColumns = ['projectname', 'projectcode', 'sponsor', 'startdate'];
    }
    this.adduserGroup = this._formBuilder.group({
      Jobdescription: [''],
    });
    this.getprojectlist()
  }
  getprojectlist() {
    this.loading = true;
    this.applyfilterData = false;
    this.pageindex = 0;
    this.pageSize = 10;
    this._AdminService.getprojectlist(this.pageindex, this.pageSize)
      .pipe(first())
      .subscribe((res: any) => {
        if (!res.isError) {
          this.loading = false
          console.log(res);
          let array = [];
          // this.totalSize = res?.responseMessage.count;

          this.projectlist = res?.responseMessage.list
          this.dataSource = new MatTableDataSource(array);
          this.totalSize = res?.responseMessage.count;
          console.log(res.responseMessage);

          if (res.responseMessage == "No record found.") {
            this.listdata = true;
          } else {
            this.listdata = false;
          }

          if (this.listdata == false) {
            for (let item of res?.responseMessage.list) {
              let d = new Date(item?.start_date);
              item.start_date = moment(d).format('MMMM D, YYYY');
              array.push(item);
            }
          }
          setTimeout(() => {
            this.paginator.pageSize = 0;
            this.paginator.pageIndex = 0;
          });


          // setTimeout(() => {

          // });
        }
        else {
          this.loading = false
          const options = { opacity: 1, timeOut: 2000, tapToDismiss: true };
          this.toastrService.warning('', res.errorMessage, options);
        }
      },
        err => {
          const options = { opacity: 1, timeOut: 2000, tapToDismiss: true };
          console.log(err);

        });
  }
  getNext(event) {
    this.loading = true;
    let array = [];
    this._AdminService.getprojectlist(event.pageIndex, event.pageSize)
      .pipe(first())
      .subscribe((res: any) => {
        console.log(res)
        if (!res.isError) {
          this.loading = false;
          this.projectlist = res?.responseMessage.list;
          this.dataSource = new MatTableDataSource(array);
          for (let item of res?.responseMessage.list) {
            let d = new Date(item?.start_date);
            item.start_date = moment(d).format('MMMM D, YYYY');
            array.push(item);
          }
          // setTimeout(() => {
          //   this.paginator.pageSize = 0;
          //   this.paginator.pageIndex = 0;
          // });
        }
        else {
          this.loading = false
          this.loading = false;
          const options = { opacity: 1, timeOut: 2000, tapToDismiss: true };
          this.toastrService.warning('', res.errorMessage, options);
        }
      },
        err => {
          this.loading = false;
          const options = { opacity: 1, timeOut: 2000, tapToDismiss: true };
          this.toastrService.warning('', err?.error, options);
        });
  }
  addprojectcomponent() {
    const dialogRef = this.dialog.open(AddprojectComponent, {
      width: '100%',
      data: '',
      panelClass: 'Addnewproduct',
    });
    dialogRef.afterClosed().subscribe(result => {
      console.log(result);
      if (result.data == "yes") {
        if (result.data) {
          console.log(result.data);
          this.getprojectlist()

        }
      }
    });
  }
  editprojectcomponent(ele) {
    const dialogRef = this.dialog.open(EditprojectComponent, {
      width: '100%',
      data: ele.project_id,
      panelClass: 'editnewproduct',
    });
    dialogRef.afterClosed().subscribe(result => {
      console.log(result);
      if (result.data == "yes") {
        if (result.data) {
          console.log(result.data);
          this.getprojectlist()

        }
      }
    });
  }
  assign(ele) {
    console.log(ele);

    const dialogRef = this.dialog.open(AssignuserComponent, {
      width: '40%',
      data: ele.project_id,
      panelClass: 'Assignuser',
    });
    dialogRef.afterClosed().subscribe(result => {
      console.log(result);
      // if (result.data == "yes") {

      // }
    });
  }
  addusercomponent() {

  }
  logout() {
    this.authenticationService.logout();
    this.router.navigate(['']);
  }




  searchuser(event?) {
    let searchstring = this.adduserGroup.value.Jobdescription.trim()
    console.log(searchstring)
    console.log(event);

    if (event) {
      this.pageindex = event.pageIndex
      this.pageSize = event.pageSize
    } else {
      this.pageindex = 0
      this.pageSize = 10
    }
    if (this.adduserGroup.value.Jobdescription.trim() != "") {
      if (searchstring) {
        this.applyfilterData = true;
      } else {
        this.applyfilterData = false;
        return;
      }
      this.loading = true;
      this.Fsearchstring = searchstring;
      console.log(this.Fsearchstring);
      this._AdminService.projectlistfilter(searchstring, this.pageindex, this.pageSize)
        .pipe(first())
        .subscribe((res: any) => {
          if (!res.isError) {
            console.log(res)
            let array = [];
            this.loading = false;
            this.projectlist = res?.responseMessage.list;
            this.dataSource = new MatTableDataSource(this.projectlist);
            // this.search = true;
            console.log(this.projectlist);
            if (this.projectlist == undefined) {
              console.log(this.dataSource);
              this.dataSource = new MatTableDataSource([]);
              this.listdata = true
            } else {
              this.totalSize = res?.responseMessage.count;
              this.listdata = false
            }
            for (let item of res?.responseMessage.list) {
              let d = new Date(item?.start_date);
              item.start_date = moment(d).format('MMMM D, YYYY');
              array.push(item);
            }

            // setTimeout(() => {
            //   this.paginator.pageSize = 0;
            //   this.paginator.pageIndex = 0;
            // });
          }
          else {
            const options = { opacity: 1, timeOut: 2000, tapToDismiss: true };
            this.toastrService.warning('', res.errorMessage, options);
            this.loading = false;
          }
        },
          err => {
            const options = { opacity: 1, timeOut: 2000, tapToDismiss: true };
            this.toastrService.warning('', err?.error, options);
            this.loading = false;
          });
    } else {
      this.getprojectlist()
    }
  }


}

