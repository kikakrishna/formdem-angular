import { ComponentFixture, TestBed } from '@angular/core/testing';

import { ConfimdeleteComponent } from './confimdelete.component';

describe('ConfimdeleteComponent', () => {
  let component: ConfimdeleteComponent;
  let fixture: ComponentFixture<ConfimdeleteComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ ConfimdeleteComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(ConfimdeleteComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
