import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-confimdelete',
  templateUrl: './confimdelete.component.html',
  styleUrls: ['./confimdelete.component.css']
})
export class ConfimdeleteComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
