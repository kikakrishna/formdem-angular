import { RouterModule } from "@angular/router";
import { UserListComponent } from "./user-list.component";
export const UserListRoutes: RouterModule [] = [
    {
        path: '',
        component: UserListComponent
    }
]