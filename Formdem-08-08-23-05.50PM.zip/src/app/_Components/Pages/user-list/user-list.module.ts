import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { RouterModule } from '@angular/router';
import { UserListComponent } from './user-list.component';
import { UserListRoutes } from './user-list.routes';
import { MatCardModule } from '@angular/material/card';
import { MatTableModule } from '@angular/material/table';
import { MatButtonModule } from '@angular/material/button';
import {MatSelectModule} from '@angular/material/select';
import { MatMenuModule } from '@angular/material/menu';
import { MatIconModule } from '@angular/material/icon';
import { MatInputModule } from '@angular/material/input';
import { MatPaginatorModule } from '@angular/material/paginator';
import { MatSlideToggleModule } from '@angular/material/slide-toggle';
import { AdduserComponent } from '../adduser/adduser.component';
 import {MatRadioModule} from '@angular/material/radio';
 import { MatFormFieldModule } from '@angular/material/form-field';
 import { EdituserComponent } from '../edituser/edituser.component';
import { MatDialogModule } from '@angular/material/dialog';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { UpdateUserpasswordComponent } from '../update-userpassword/update-userpassword.component';
@NgModule({
  declarations: [UserListComponent,AdduserComponent,UpdateUserpasswordComponent],
  imports: [
    CommonModule,
    RouterModule.forChild(UserListRoutes),
    MatCardModule,
    MatTableModule,
    MatButtonModule,
    MatSelectModule,
    MatMenuModule,
    MatIconModule,
    MatInputModule,
    MatPaginatorModule,
    MatSlideToggleModule,
    MatRadioModule,
    MatFormFieldModule,
    MatDialogModule,
    FormsModule,
    ReactiveFormsModule,
    

  ],
  entryComponents: [
    AdduserComponent,
    EdituserComponent,
     UpdateUserpasswordComponent
    
  ]
})
export class UserListModule { }