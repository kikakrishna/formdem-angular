import { Component, OnInit, Inject } from '@angular/core';
import { FormGroup } from '@angular/forms';
import { FormBuilder, Validators } from '@angular/forms';
import { MatDialogRef, MAT_DIALOG_DATA } from '@angular/material/dialog';
import { AdminService } from 'src/app/_Services/admin.sevice';
import { ToastService } from 'ng-uikit-pro-standard';
import { first } from 'rxjs/operators';

@Component({
  selector: 'app-excipientdetele',
  templateUrl: './excipientdetele.component.html',
  styleUrls: ['./excipientdetele.component.css']
})
export class ExcipientdeteleComponent implements OnInit {


  addfamilyGroup: FormGroup;
  constructor(public _formBuilder: FormBuilder,private _AdminService: AdminService,private toastrService: ToastService,
    public dialogRef: MatDialogRef<ExcipientdeteleComponent>,  @Inject(MAT_DIALOG_DATA) public data: any) { }

  ngOnInit(): void {
    // this.addfamilyGroup = this._formBuilder.group({
    //   FullName: [''],
    //   Relationship: [''],
    //   PatientID: [''],
    //   Age: [''],
    //   MobileNo: [''],
    //   Email: [''],
    // });
this.data
console.log(this.data);
  }
  // submit() {
  //   // console.log(this.addfamilyGroup.value)
  //   this.dialogRef.close({ data: "yes" });

  // }
  
  removeExcipient() {
    console.log(this.data);
    let jason = {
      "excipient_id": this.data
    }
    console.log()
    this._AdminService.deleteexcipient(jason)
      .pipe(first())
      .subscribe((res: any) => {
        if (!res.error) {
          console.log(res);
          const options = { opacity: 1, timeOut: 2000, tapToDismiss: true };
          this.toastrService.success('', res.responseMessage, options);
            this.dialogRef.close({ data: "yes" });

        //  this.getjobstatus()

        }
        else {
          const options = { opacity: 1, timeOut: 2000, tapToDismiss: true };
          this.toastrService.warning('', res.errorMessage, options);
        }
      },
        err => {
          const options = { opacity: 1, timeOut: 2000, tapToDismiss: true };
          console.log(err);

        });
  }

  onNoClick(): void {
    // this.dialogRef.close();
    this.dialogRef.close({ data: "no" });

  }


}