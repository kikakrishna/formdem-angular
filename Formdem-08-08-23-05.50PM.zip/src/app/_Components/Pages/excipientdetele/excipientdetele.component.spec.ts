import { ComponentFixture, TestBed } from '@angular/core/testing';

import { ExcipientdeteleComponent } from './excipientdetele.component';

describe('ExcipientdeteleComponent', () => {
  let component: ExcipientdeteleComponent;
  let fixture: ComponentFixture<ExcipientdeteleComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ ExcipientdeteleComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(ExcipientdeteleComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
