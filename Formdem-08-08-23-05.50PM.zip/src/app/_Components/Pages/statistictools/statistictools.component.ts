import { Component, OnInit,ViewChild,Input } from '@angular/core';
import { MatTableDataSource } from '@angular/material/table';
import { MatPaginator } from '@angular/material/paginator';
import { FormControl, FormGroup, NgForm,FormBuilder, Validators } from '@angular/forms';
import { Router } from '@angular/router';
import { first } from 'rxjs/operators';
import { HttpClient } from '@angular/common/http';
import { ToastService } from 'ng-uikit-pro-standard';
import * as moment from 'moment';

@Component({
  selector: 'app-statistictools',
  templateUrl: './statistictools.component.html',
  styleUrls: ['./statistictools.component.css']
})
export class StatistictoolsComponent implements OnInit {
  viewscreen1: boolean = false;
  viewscreen2: boolean = false;
  viewscreen3: boolean = false;
  viewscreen4: boolean = false;
  viewscreen5: boolean = false;
  viewscreen6: boolean = false;
  closecreen: boolean = false;
  
  displayedColumns = ['status', 'description', 'edit', 'remove'];

  constructor(
    private http: HttpClient,
    public toastrService: ToastService,
    private router: Router,
    ) { }

  ngOnInit(): void {

  }

  closeclick() {
    this.closecreen = false;
  }
}
