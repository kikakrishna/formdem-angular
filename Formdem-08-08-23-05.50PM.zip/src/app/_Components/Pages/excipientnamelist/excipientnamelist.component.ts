import { Component, OnInit, ViewChild, ElementRef } from '@angular/core';
import { MatTableDataSource } from '@angular/material/table';
import { MatPaginator } from '@angular/material/paginator';
import { AuthenticationService } from 'src/app/_Services/authentication.service';
import { Router } from '@angular/router';
import { AdminService } from 'src/app/_Services/admin.sevice';
import { first } from 'rxjs/operators';
import { ToastService } from 'ng-uikit-pro-standard';
import * as moment from 'moment';
import { FormBuilder, Validators } from '@angular/forms';
import { FormGroup } from '@angular/forms';
import { ExcipientdeteleComponent } from '../excipientdetele/excipientdetele.component';
import { MatDialog } from '@angular/material/dialog';

@Component({
  selector: 'app-excipientnamelist',
  templateUrl: './excipientnamelist.component.html',
  styleUrls: ['./excipientnamelist.component.css']
})
export class ExcipientnamelistComponent implements OnInit {

  displayedColumns: string[] = ['excipientname', 'action'];
  // dataSource = ELEMENT_DATA;
  dataSource = new MatTableDataSource<any>([]);
  @ViewChild(MatPaginator) paginator: MatPaginator;
  @ViewChild('paginator', { static: false }) joblistpaginator: MatPaginator;
  public filerpastform_pagination_show: boolean;
  //  public jobstatus: any = new MatTableDataSource([]);
  public totalSize: any;
  public pageindex = 0;
  public pageSize = 10;
  filterData: boolean;
  firstname: string;
  lastname: string;
  joblist: any;
  loading: boolean;
  nolist: boolean;
  data: string;
  ExcListGroup: FormGroup;
  searchinput: any;
  Fsearchstring: any;
  applyfilterData: boolean = false;
  multiexp: FormGroup;
  role:any;
  constructor(public dialog: MatDialog,public authenticationService: AuthenticationService, private router: Router,
    public _formBuilder: FormBuilder,
    private _AdminService: AdminService, private toastrService: ToastService) {
    this.firstname = sessionStorage.getItem("firstname");
    this.lastname = sessionStorage.getItem("lastname")
    this.role = sessionStorage.getItem("role");
  }
  @ViewChild('UploadFileInput') uploadFileInput: ElementRef;

  ngOnInit(): void {
    this.getjobstatus()
    this.dataSource.paginator = this.paginator
    this.ExcListGroup = this._formBuilder.group({
      Jobdescription: [''],
    });
    if (this.role == "Manager") {
      this.displayedColumns = ['excipientname', 'action'];
    }
    else{
      this.displayedColumns = ['excipientname'];
    }
    this.multiexp = this._formBuilder.group({
      excipientname: [''],
      smiles: [''],

    });
  }
  logout() {
    this.authenticationService.logout();
    this.router.navigate(['']);
  }
  getjobstatus() {
    this.loading = true
    this._AdminService.getexcipientlist(this.pageindex, this.pageSize)
      .pipe(first())
      .subscribe((res: any) => {
        if (!res.isError) {
          console.log(res);
          this.loading = false
          let array = [];
          this.totalSize = res?.responseMessage.count;
          this.joblist = res?.responseMessage.list
          this.dataSource = new MatTableDataSource(res?.responseMessage.list);
          this.totalSize = res?.responseMessage.count;
          this.pageindex = 0;
          // if (this.joblist != undefined) {

          //   for (let item of res?.responseMessage.list) {
          //     let d = new Date(item?.submissiondate);
          //     item.submissiondate = moment(d).format('MMMM D, YYYY');
          //     array.push(item);
          //   }
          // }
          if (this.joblist.length == undefined) {
            // if (array.length == 0) {
            this.nolist = true;
          } else {
            this.nolist = false;

          }

          // setTimeout(() => {
          //   // this.dataSource.paginator = this.paginator
          // });
        }
        else {
          const options = { opacity: 1, timeOut: 2000, tapToDismiss: true };
          this.toastrService.warning('', res.errorMessage, options);
        }
      },
        err => {
          const options = { opacity: 1, timeOut: 2000, tapToDismiss: true };
          console.log(err);

        });
  }
  getNext(event) {
    this.loading = true;
    let array = [];
    this._AdminService.getexcipientlist(event.pageIndex, event.pageSize)
      .pipe(first())
      .subscribe((res: any) => {
        console.log(res)
        if (!res.isError) {
          this.loading = false;
          this.joblist = res?.responseMessage.list;
          this.dataSource = new MatTableDataSource(res?.responseMessage.list);


          if (this.joblist.length == undefined) {
            // if (array.length == 0) {
            this.nolist = true;
          } else {
            this.nolist = false;

          }
        }
        else {
          this.loading = false;
          const options = { opacity: 1, timeOut: 2000, tapToDismiss: true };
          this.toastrService.warning('', res.errorMessage, options);
        }
      },
        err => {
          this.loading = false;
          const options = { opacity: 1, timeOut: 2000, tapToDismiss: true };
          this.toastrService.warning('', err?.error, options);
        });
  }

  filterGetnext(event) {
    this.loading = true;
    let array = [];
    this._AdminService.Searchexcipientlist(event.pageIndex, event.pageSize, this.Fsearchstring)
      .pipe(first())
      .subscribe((res: any) => {
        console.log(res)
        if (!res.isError) {
          this.loading = false;
          this.joblist = res?.responseMessage.list;
          this.dataSource = new MatTableDataSource(array);
          if (this.joblist != undefined) {
            for (let item of res?.responseMessage.list) {
              let d = new Date(item?.submissiondate);
              item.submissiondate = moment(d).format('MMMM D, YYYY');
              array.push(item);
            }
          }

          if (this.joblist == undefined) {
            // if (array.length == 0) {
            this.nolist = true;
          } else {
            this.nolist = false;

          }
        }
        else {
          this.loading = false;
          const options = { opacity: 1, timeOut: 2000, tapToDismiss: true };
          this.toastrService.warning('', res.errorMessage, options);
        }
      },
        err => {
          this.loading = false;
          const options = { opacity: 1, timeOut: 2000, tapToDismiss: true };
          this.toastrService.warning('', err?.error, options);
        });
  }

  csvdownload() {

    this.loading = true
    this._AdminService.excipientlistcsv()
      .pipe(first())
      .subscribe((res: any) => {
        if (!res.isError) {
          this.loading = false
          console.log(res);
          const newBlob = new Blob([res], { type: 'application/csv' });
          this.data = window.URL.createObjectURL(res);
          const file_path = this.data;
          const down = document.createElement('A') as HTMLAnchorElement;
          down.href = file_path;
          down.download = "Excipient list"
          document.body.appendChild(down);
          down.click();
          document.body.removeChild(down);

        }
        else {
          this.loading = false
          const options = { opacity: 1, timeOut: 2000, tapToDismiss: true };
          this.toastrService.warning('', res.errorMessage, options);

        }
      },
        err => {
          const options = { opacity: 1, timeOut: 2000, tapToDismiss: true };
          console.log(err);

        });
  }


  pdfdownload() {
    this.loading = true
    // this._AdminService.excipientlistcsv()
    //   .pipe(first())
    //   .subscribe((res: any) => {
    //     if (!res.isError) {
    //       this.loading = false
    //       console.log(res);
    //       const newBlob = new Blob([res], { type: 'application/csv' });
    //       this.data = window.URL.createObjectURL(res);
    //       const file_path = this.data;
    //       const down = document.createElement('A') as HTMLAnchorElement;
    //       down.href = file_path;
    //       down.download = "Multiple-jobs"
    //       document.body.appendChild(down);
    //       down.click();
    //       document.body.removeChild(down);

    //     }
    //     else {
    //       this.loading = false
    //       const options = { opacity: 1, timeOut: 2000, tapToDismiss: true };
    //       this.toastrService.warning('', res.errorMessage, options);

    //     }
    //   },
    //     err => {
    //       const options = { opacity: 1, timeOut: 2000, tapToDismiss: true };
    //       console.log(err);

    //     });
  }
  searchFilter() {
    const filterValue = this.searchinput;
    let searchstring = filterValue.trim()
    console.log(searchstring)
    this.pageindex = 0;
    this.pageSize = 10;
    if (searchstring != "") {

      if (searchstring) {
        this.applyfilterData = true;
      } else {
        this.applyfilterData = false;
        return;
      }
      this.loading = true
      this.Fsearchstring = searchstring
      this._AdminService.Searchexcipientlist(this.pageindex, this.pageSize, searchstring)
        .pipe(first())
        .subscribe((res: any) => {
          if (!res.isError) {
            console.log(res);
            this.loading = false
            let array = [];
            this.totalSize = res?.responseMessage.count;
            this.joblist = res?.responseMessage.list
            this.dataSource = new MatTableDataSource(array);
            this.totalSize = res?.responseMessage.count;
            if (this.joblist != undefined) {

              for (let item of res?.responseMessage.list) {
                let d = new Date(item?.submissiondate);
                item.submissiondate = moment(d).format('MMMM D, YYYY');
                array.push(item);
              }
            }
            if (this.joblist == undefined) {
              // if (array.length == 0) {
              this.nolist = true;
            } else {
              this.nolist = false;

            }

            // setTimeout(() => {
            //   // this.dataSource.paginator = this.paginator
            // });
          }
          else {
            const options = { opacity: 1, timeOut: 2000, tapToDismiss: true };
            this.toastrService.warning('', res.errorMessage, options);
          }
        },
          err => {
            const options = { opacity: 1, timeOut: 2000, tapToDismiss: true };
            console.log(err);

          });
    } else {
      this.getjobstatus();
    }

  }
  reset() {
    this.loading = true;
    this.searchinput = "";
    let searchstring = this.searchinput;
    this.applyfilterData = false;
    this.pageindex = 0;
    this.pageSize = 10;
    this.getjobstatus();
    this.paginator.pageIndex = 0
    this.paginator.pageSize = 10;

  }
  storefile: any;
  myfilename = '';
  fileChangeEvent(fileInput: any) {
    console.log(this.storefile);

    if (fileInput.target.files && fileInput.target.files[0]) {
      this.myfilename = '';
      Array.from(fileInput.target.files).forEach((file: File) => {
        console.log(file);
        this.storefile = file
        console.log(this.storefile)
        this.myfilename += file.name;
      });
      const reader = new FileReader();
      reader.onload = (e: any) => {
        const image = new Image();
        image.src = e.target.result;
        image.onload = rs => {          // Return Base64 Data URL
          const imgBase64Path = e.target.result;
        };
      };
      reader.readAsDataURL(fileInput.target.files[0]);      // Reset File Input to Selct Same file again
      // this.uploadFileInput.nativeElement.value = "";
    }


  }

  uploadedfileres: any;
  uploadfile() {
    console.log(this.storefile);
    console.log(this.uploadedfileres);

    if (this.multiexp.value.excipientname.trim() != null && this.multiexp.value.excipientname.trim() != "") {
      if (this.multiexp.value.smiles.trim() != null && this.multiexp.value.smiles.trim() != "") {
        if (this.storefile != null && this.storefile != "") {
          const formdatafileupload: FormData = new FormData();
          formdatafileupload.append('file', this.storefile);
          formdatafileupload.append('excipientname', this.multiexp.value.excipientname);
          formdatafileupload.append('smiles', this.multiexp.value.smiles);
          console.log(this.multiexp.value);

          this._AdminService.sendocfile(formdatafileupload)
            .pipe(first())
            .subscribe((res: any) => {
              if (!res.error) {
                console.log(res);
                this.loading = false
                this.uploadFileInput.nativeElement.value = "";
                this.multiexp.reset()
                this.storefile = ""


                console.log(this.storefile);
                console.log(this.uploadFileInput.nativeElement.value);
                console.log(this.multiexp);

                const options = { opacity: 1, timeOut: 2000, tapToDismiss: true };
                this.toastrService.success('', res.responseMessage, options);
                this.getjobstatus()
              }
              else {
                const options = { opacity: 1, timeOut: 2000, tapToDismiss: true };
                this.toastrService.warning('', res.errorMessage, options);
              }
            },
              err => {
                const options = { opacity: 1, timeOut: 2000, tapToDismiss: true };
                console.log(err);

              });
        } else {
          const options = { opacity: 1, timeOut: 2000, tapToDismiss: true };
          this.toastrService.warning('', "Please upload OC file", options);
        }
      } else {
        const options = { opacity: 1, timeOut: 2000, tapToDismiss: true };
        this.toastrService.warning('', "Please enter smiles", options);
      }
    } else {
      const options = { opacity: 1, timeOut: 2000, tapToDismiss: true };
      this.toastrService.warning('', "Please enter excipient name", options);
    }

  }

  excipientdetelecomponent(id) {
    const dialogRef = this.dialog.open(ExcipientdeteleComponent, {
      width: '100%',
      data: id,
      panelClass: 'savemolecules',
    });
    dialogRef.afterClosed().subscribe(result => {
      console.log(result);
      if (result.data == "yes") {
        if (result.data) {
          console.log(result.data);
          this.getjobstatus()

        }
      }
    });
  }

  // removeExcipient(id) {
  //   console.log(id);
  //   let jason = {
  //     "excipient_id": id
  //   }
  //   this._AdminService.deleteexcipient(jason)
  //     .pipe(first())
  //     .subscribe((res: any) => {
  //       if (!res.error) {
  //         console.log(res);
  //         const options = { opacity: 1, timeOut: 2000, tapToDismiss: true };
  //         this.toastrService.success('', res.responseMessage, options);
  //         // this.getjobstatus()

  //       }
  //       else {
  //         const options = { opacity: 1, timeOut: 2000, tapToDismiss: true };
  //         this.toastrService.warning('', res.errorMessage, options);
  //       }
  //     },
  //       err => {
  //         const options = { opacity: 1, timeOut: 2000, tapToDismiss: true };
  //         console.log(err);

  //       });
  // }
}
