import { ComponentFixture, TestBed } from '@angular/core/testing';

import { ExcipientnamelistComponent } from './excipientnamelist.component';

describe('ExcipientnamelistComponent', () => {
  let component: ExcipientnamelistComponent;
  let fixture: ComponentFixture<ExcipientnamelistComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ ExcipientnamelistComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(ExcipientnamelistComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
