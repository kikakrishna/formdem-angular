import { RouterModule } from "@angular/router";
import { ExcipientnamelistComponent } from "./excipientnamelist.component";
export const ExcipientnamelistRoutes: RouterModule [] = [
    {
        path: '',
        component: ExcipientnamelistComponent
    }
]