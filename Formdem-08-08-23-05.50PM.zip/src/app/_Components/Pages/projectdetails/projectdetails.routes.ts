import { RouterModule } from "@angular/router";
import { ProjectdetailsComponent } from "./projectdetails.component";

export const ProjectdetailsRoutes: RouterModule [] = [
    {
        path: '',
        component: ProjectdetailsComponent
    }
]