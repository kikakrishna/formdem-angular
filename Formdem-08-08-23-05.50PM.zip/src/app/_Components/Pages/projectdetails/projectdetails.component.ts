import { Component, OnInit } from '@angular/core';
import { AuthenticationService } from 'src/app/_Services/authentication.service';
import { Router } from '@angular/router';
import { ActivatedRoute } from '@angular/router';
import { AdminService } from 'src/app/_Services/admin.sevice';
import { ToastService } from 'ng-uikit-pro-standard';
import { first } from 'rxjs/operators';
import { MatTableDataSource } from '@angular/material/table';
import { MatDialog } from '@angular/material/dialog';
import * as moment from 'moment';

export interface PeriodicElement1 {
  id: number;
  firstname: string;
  lastname: string;
  emailid: string;
  phoneno: string;
  action: string;
}

const USER_DATA: PeriodicElement1[] = [
  { id: 1, firstname: 'Magesh', lastname: 'kumar', emailid: 'magesh@gmail.com', phoneno: '945456586', action: '' },
  { id: 2, firstname: 'Magesh', lastname: 'kumar', emailid: 'magesh@gmail.com', phoneno: '945456586', action: '' },
  { id: 3, firstname: 'Magesh', lastname: 'kumar', emailid: 'magesh@gmail.com', phoneno: '945456586', action: '' },
  { id: 4, firstname: 'Magesh', lastname: 'kumar', emailid: 'magesh@gmail.com', phoneno: '945456586', action: '' },
  { id: 5, firstname: 'Magesh', lastname: 'kumar', emailid: 'magesh@gmail.com', phoneno: '945456586', action: '' },
  { id: 6, firstname: 'Magesh', lastname: 'kumar', emailid: 'magesh@gmail.com', phoneno: '945456586', action: '' },
  { id: 7, firstname: 'Magesh', lastname: 'kumar', emailid: 'magesh@gmail.com', phoneno: '945456586', action: '' },


];


export interface PeriodicElement2 {
  id: number;
  jobdescription: string;
  author: string;
  submissiondate: string;
  jobstatus: string;
  action: string;
}

const JOB_DATA: PeriodicElement2[] = [
  { id: 1, jobdescription: 'SP-P1-25C-75RH', author: 'Maheshwari K', submissiondate: '04-04-2023', jobstatus: 'Algorithm 2 is running', action: '' },
  { id: 2, jobdescription: 'SP-P1-25C-75RH', author: 'Maheshwari K', submissiondate: '04-04-2023', jobstatus: 'Algorithm 2 is running', action: '' },
  { id: 3, jobdescription: 'SP-P1-25C-75RH', author: 'Maheshwari K', submissiondate: '04-04-2023', jobstatus: 'Algorithm 2 is running', action: '' },
  { id: 4, jobdescription: 'SP-P1-25C-75RH', author: 'Maheshwari K', submissiondate: '04-04-2023', jobstatus: 'Algorithm 2 is running', action: '' },
  { id: 5, jobdescription: 'SP-P1-25C-75RH', author: 'Maheshwari K', submissiondate: '04-04-2023', jobstatus: 'Algorithm 2 is running', action: '' },
  { id: 6, jobdescription: 'SP-P1-25C-75RH', author: 'Maheshwari K', submissiondate: '04-04-2023', jobstatus: 'Algorithm 2 is running', action: '' },
  { id: 7, jobdescription: 'SP-P1-25C-75RH', author: 'Maheshwari K', submissiondate: '04-04-2023', jobstatus: 'Algorithm 2 is running', action: '' },
  { id: 8, jobdescription: 'SP-P1-25C-75RH', author: 'Maheshwari K', submissiondate: '04-04-2023', jobstatus: 'Algorithm 2 is running', action: '' },
];


@Component({
  selector: 'app-projectdetails',
  templateUrl: './projectdetails.component.html',
  styleUrls: ['./projectdetails.component.css']
})
export class ProjectdetailsComponent implements OnInit {

  displayedColumns1: string[] = ['firstname', 'lastname', 'emailid', 'phoneno', 'action'];
  userdataSource = new MatTableDataSource<any>([]);;
  jobdataSource = new MatTableDataSource<any>([]);;
  displayedColumns2: string[] = ['jobdescription', 'author', 'submissiondate', 'jobstatus', 'jobaction'];
  // jobdataSource = JOB_DATA;
  firstname: string;
  lastname: string;
  loading: boolean;
  paramprojectid: any;
  pageindex = 0;
  pageSize = 10;
  dataSource = new MatTableDataSource<any>([]);
  projectdetails: any;
  userlist: boolean;
  joblist: boolean;
  constructor(public authenticationService: AuthenticationService, private router: Router,
    private _AdminService: AdminService, public dialog: MatDialog,
    public _activatedRoute: ActivatedRoute, private toastrService: ToastService,) {
    this.firstname = sessionStorage.getItem("firstname");
    this.lastname = sessionStorage.getItem("lastname")
  }

  ngOnInit(): void {

    this._activatedRoute.paramMap.subscribe(params => {
      this.paramprojectid = +params.get('id');
    });
    console.log(this.paramprojectid);


    this.userlistload();
    this.getprojectjobdetail();
  }

  userlistload() {
    this.loading = true
    this._AdminService.getuserprojectdetail(this.paramprojectid, this.pageindex, this.pageSize)
      .pipe(first())
      .subscribe((res: any) => {
        if (!res.isError) {
          console.log(res)
          let array = [];
          this.loading = false;
          this.projectdetails = res.responseMessage.projectDetail
          this.userdataSource = new MatTableDataSource(res.responseMessage?.userList?.projectUserList);
          console.log(this.userdataSource.filteredData.length);

          if (this.userdataSource.filteredData.length == 0) {
            this.userlist = true;
          } else {
            this.userlist = false;

          }
          // this.search = true;

        }
        else {
          const options = { opacity: 1, timeOut: 2000, tapToDismiss: true };
          this.toastrService.warning('', res.errorMessage, options);
          this.loading = false;
        }
      },
        err => {
          const options = { opacity: 1, timeOut: 2000, tapToDismiss: true };
          this.toastrService.warning('', err?.error, options);
          this.loading = false;
        });
  }
  logout() {
    this.authenticationService.logout();
    this.router.navigate(['']);
  }

  jobdetails: any;
  getprojectjobdetail() {
    this._AdminService.getjobprojectdetail(this.paramprojectid, this.pageindex, this.pageSize)
      .pipe(first())
      .subscribe((res: any) => {
        if (!res.isError) {
          console.log(res)
          let array = [];
          this.loading = false;
          this.jobdetails = res?.responseMessage.projectJobList
          this.jobdataSource = new MatTableDataSource(array);

          if (res?.responseMessage.projectJobList) {
            for (let item of res?.responseMessage.projectJobList) {
              let d = new Date(item?.submissiondate);
              item.submissiondate = moment(d).format('MMMM D, YYYY');
              array.push(item);
            }
          }

          console.log(array.length);

          if (array.length == 0) {
            this.joblist = true;
          } else {
            this.joblist = false;

          }
          // this.search = true;
        }
        else {
          const options = { opacity: 1, timeOut: 2000, tapToDismiss: true };
          this.toastrService.warning('', res.errorMessage, options);
          this.loading = false;
        }
      },
        err => {
          const options = { opacity: 1, timeOut: 2000, tapToDismiss: true };
          this.toastrService.warning('', err?.error, options);
          this.loading = false;
        });
  }

  Unassignclick(ele) {
    console.log(ele);
    // const dialogRef = this.dialog.open(UnassignuserComponent, {
    //   width: '40%',
    //   data: ele,
    //   panelClass: 'Assignuser',
    // });
    // dialogRef.afterClosed().subscribe(result => {
    //   console.log(result);
    //   if (result.data == "yes") {

    //   }
    // });


    let payload = {

      "projectid": this.paramprojectid,
      "userid": ele.user_id,


    }
    this.loading = true
    console.log(payload);

    this._AdminService.unassignuser(payload)
      .pipe(first())
      .subscribe((res: any) => {
        console.log(res)
        if (!res.isError) {
          this.loading = false;
          const options = { opacity: 1, timeOut: 2000, tapToDismiss: true };
          this.toastrService.success('', res.responseMessage, options);
          this.userlistload();
        }
        else {
          this.loading = false;
          const options = { opacity: 1, timeOut: 2000, tapToDismiss: true };
          this.toastrService.warning('', res.errorMessage, options);
        }
      },
        err => {
          this.loading = false;
          const options = { opacity: 1, timeOut: 2000, tapToDismiss: true };
          this.toastrService.warning('', err?.error, options);
        });
  }
  data: any;
  jobname: any;
  pdfdownload(ele) {
    console.log(ele);
    this.jobname = ele.jobname.replace(/\./g, "-");
    this.loading = true
    this._AdminService.downloadpdf(ele.jobid)
      .pipe(first())
      .subscribe((res: any) => {
        if (!res.isError) {
          this.loading = false
          console.log(res);
          const newBlob = new Blob([res], { type: 'application/csv' });
          this.data = window.URL.createObjectURL(res);
          const file_path = this.data;
          const down = document.createElement('A') as HTMLAnchorElement;
          down.href = file_path;
          down.download = this.jobname
          document.body.appendChild(down);
          down.click();
          document.body.removeChild(down);

        }
        else {
          this.loading = false
          const options = { opacity: 1, timeOut: 2000, tapToDismiss: true };
          this.toastrService.warning('', res.errorMessage, options);

        }
      },
        err => {
          const options = { opacity: 1, timeOut: 2000, tapToDismiss: true };
          console.log(err);

        });
  }
}
