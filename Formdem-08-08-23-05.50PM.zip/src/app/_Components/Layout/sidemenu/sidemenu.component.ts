import { Component, OnInit } from '@angular/core';
import { Router, ActivatedRoute } from '@angular/router';


@Component({
  selector: 'app-sidemenu',
  templateUrl: './sidemenu.component.html',
  styleUrls: ['./sidemenu.component.css']
})
export class SidemenuComponent implements OnInit {
  userRole: any;
  currentrole: string;
  imageURL: string;
  activerou: boolean;
  panelOpenState = false;
  exp: boolean = false;
  constructor(private activeroute: ActivatedRoute, private route: Router) {
    this.userRole = sessionStorage.getItem("role");
  }

  ngOnInit() {
    // this.currentrole =  sessionStorage.getItem('userName');
    // const url = sessionStorage.getItem('profile');
    // if( url != 'null'){
    //   this.imageURL = url;
    // }
    // else{
    //   this.imageURL = "../assets/images/noimage.webp";
    // }
  }
  toggleAccordian(event) {
    const element = event.target;
    element.classList.toggle('active');

    const panel = element.nextElementSibling;
    if (panel.style.maxHeight) {
      panel.style.maxHeight = null;
    } else {
      panel.style.maxHeight = panel.scrollHeight + 'px';
    }
  }
  expand() {
    this.exp = !this.exp;
    console.log("fghfgh")
  }
}
