import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { MatListModule } from '@angular/material/list';
import { RouterModule } from '@angular/router';
import { MatMenuModule } from '@angular/material/menu';
import { MatIconModule } from '@angular/material/icon';
import { SidemenuComponent } from './sidemenu.component';
import { MatExpansionModule } from '@angular/material/expansion';
@NgModule({
  declarations: [SidemenuComponent],
  imports: [
    CommonModule,
    MatListModule,
    RouterModule,
    MatMenuModule,
    MatIconModule,
    MatExpansionModule
  ],
  exports: [SidemenuComponent]
})
export class SidemenuModule { }
