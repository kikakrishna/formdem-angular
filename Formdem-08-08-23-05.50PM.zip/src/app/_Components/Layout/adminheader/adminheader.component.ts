import { Component, OnInit, OnDestroy, Inject } from '@angular/core';
import { MatDialog } from '@angular/material/dialog';
import { AuthenticationService } from 'src/app/_Services/authentication.service';
import { Router } from '@angular/router';
import { ToastService } from 'ng-uikit-pro-standard';
import { Subject } from 'rxjs';
import { filter, takeUntil } from 'rxjs/operators';
import { FormControl, FormGroup, NgForm,FormBuilder, Validators } from '@angular/forms';
import { first } from 'rxjs/operators';
import { HttpClient } from '@angular/common/http';
import * as moment from 'moment';



@Component({
  selector: 'app-adminheader',
  templateUrl: './adminheader.component.html',
  styleUrls: ['./adminheader.component.css']
})
export class AdminheaderComponent implements OnInit {
  
  menusection: boolean = false;
  userinfo;
  username;
  usernamesession;

  constructor(
   public authenticationService: AuthenticationService, public dialog: MatDialog, public router: Router,
    private toastrService: ToastService
) { }

  ngOnInit(): void {
    

  }

  logout() { // Add log out function here
    localStorage.removeItem('Loggedin-user');  
    // this.authService.logoutRedirect({
    //  postLogoutRedirectUri: 'https://localhost:4200'
    // });
  }

  updatePassword() {
  }

  openmenu() {
    this.menusection = !this.menusection;
  }

  closemenu() {
    this.menusection = false;
  }


}
