import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-content',
  templateUrl: './content.component.html',
  styleUrls: ['./content.component.css']
})
export class ContentComponent implements OnInit {
  role: string;
  patientcontentsection: boolean;
  commoncontentsection: boolean;
  clinicadmincontentsection: boolean;

  constructor() { }

  ngOnInit(): void {
    this.role = sessionStorage.getItem('Role');
    if(this.role === 'patient'){
      this.patientcontentsection = true;
      this.commoncontentsection = false;
      this.clinicadmincontentsection = false;
    }
    else if(this.role == 'clinicadmin'){
      this.clinicadmincontentsection = true;
      this.patientcontentsection = false;
      this.commoncontentsection = false;
    }
    else{
      this.patientcontentsection = false;
      this.clinicadmincontentsection = false;
      this.commoncontentsection = true;
    }
  }

}
