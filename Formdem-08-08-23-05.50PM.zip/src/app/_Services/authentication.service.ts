import { Component, OnInit, Injectable } from '@angular/core';
import { Router } from "@angular/router";
import { HttpClient, HttpHeaders } from '@angular/common/http';
import { BehaviorSubject } from 'rxjs';
import { Observable, of, pipe, throwError } from 'rxjs';
import { map, switchMap, debounceTime, catchError } from 'rxjs/operators';
import { environment } from '../../environments/environment';
import { User } from '../_Models/user';
import { DarkModeService } from 'angular-dark-mode';
declare var $: any;



@Injectable({ providedIn: 'root' })
export class AuthenticationService {
  public currentUserSubject: BehaviorSubject<User>;
  public currentUser: Observable<User>;
  public token: String;
  public firstname;
  public lastname;

  constructor(private http: HttpClient, private router: Router,
    private darkModeService: DarkModeService) {
    this.currentUserSubject = new BehaviorSubject<any>(sessionStorage.getItem('currentUser'));
    this.currentUser = this.currentUserSubject.asObservable();
  }

  public get currentUserValue(): User {
    return this.currentUserSubject.value;
  }

  darkMode$ = this.darkModeService.darkMode$;


  // --------------------------------------------------------------


  login2(logindata) {
    console.log(environment.apiUrl + "Login")
    console.log(logindata)
    // return this.http.post(`${environment.apiUrl}Login`, logindata)
    return this.http.post(`${environment.apiUrl}Login`, logindata)
      .pipe(
        map((user: any) => {
          // login successful if there's a jwt token in the response
          if (!user.error) {
            const userdetails = user.responseMessage;
            sessionStorage.setItem('currentUser', userdetails.token);
            sessionStorage.setItem('email', userdetails.email);
            sessionStorage.setItem('userguid', userdetails.userguid);
            sessionStorage.setItem('firstname', userdetails.firstname);
            sessionStorage.setItem('lastname', userdetails.lastname);
            sessionStorage.setItem('role', userdetails.rolename);

            // sessionStorage.setItem('clinicPatientId',userdetails.clinicPatientId);
            sessionStorage.setItem('profile', userdetails.profile);
            // sessionStorage.setItem('cliniclogo', userdetails.clinicLogo);
            var event = document.createEvent("Event");
            event.initEvent("messageStorage", true, true);
            window.dispatchEvent(event);
            this.currentUserSubject.next(user.responseMessage.token);
          }
          else {
            console.log(user.errorMessage);
          }
          return user;
        }),
        catchError(err => {
          console.log("auth-err");
          
          return throwError(err);
        })
      );
  }


  // ---------------------------------------------------------------


  loginstudent(user: User) {
    const userval = {
      "email": user.email,
      "password": user.password
    }
    return this.http.post(`${environment.apiUrl}/login`, userval)
      .pipe(
        map((student: any) => {
          // login successful if there's a jwt token in the response
          if (!student.error) {
            console.log(student)
            if (student?.data?.user?.role == 'admin' || student?.data?.user?.role == 'instituteadmin') {
              const localstor = JSON.parse(localStorage.getItem("dark-mode"));
              localstor.darkMode = false;
              localStorage.setItem("dark-mode", JSON.stringify(localstor));

              this.darkModeService.disable();
            }
            const studentdetails = student.data;
            sessionStorage.setItem("userinfo", JSON.stringify(studentdetails))
            sessionStorage.setItem('currentUser', studentdetails.accesstoken);
            sessionStorage.setItem('Role', studentdetails.user.role);
            sessionStorage.setItem('environment', environment.apiUrl);
            sessionStorage.setItem('instituteguid', studentdetails.institutedetails.InstituteGuid);
            sessionStorage.setItem('currency', studentdetails.currencysymbol);
            var event = document.createEvent("Event");
            event.initEvent("storage", true, true);
            window.dispatchEvent(event);
            console.log(studentdetails.accesstoken)
            this.currentUserSubject.next(studentdetails.accesstoken);
            this.startRefreshTokenTimer();
          }
          else {
            console.log(student.errorMessage);
          }
          return student;
        }),
        catchError(err => {
          return throwError(err);
        })
      );
  }

  loginstudentpopup(payload) {
    // const userval = {
    //   "email": user.email,
    //   "password": user.password
    // }
    return this.http.post(`${environment.apiUrl}/login`, payload)
      .pipe(
        map((student: any) => {
          // login successful if there's a jwt token in the response
          if (!student.error) {
            console.log(student)
            if (student?.data?.user?.role == 'admin' || student?.data?.user?.role == 'instituteadmin') {
              const localstor = JSON.parse(localStorage.getItem("dark-mode"));
              localstor.darkMode = false;
              localStorage.setItem("dark-mode", JSON.stringify(localstor));

              this.darkModeService.disable();
            }
            const studentdetails = student.data;
            sessionStorage.setItem("userinfo", JSON.stringify(studentdetails))
            sessionStorage.setItem('currentUser', studentdetails.accesstoken);
            sessionStorage.setItem('Role', studentdetails.user.role);
            sessionStorage.setItem('environment', environment.apiUrl);
            sessionStorage.setItem('instituteguid', studentdetails.institutedetails.InstituteGuid);
            sessionStorage.setItem('currency', studentdetails.currencysymbol);
            var event = document.createEvent("Event");
            event.initEvent("storage", true, true);
            window.dispatchEvent(event);
            console.log(studentdetails.accesstoken)
            this.currentUserSubject.next(studentdetails.accesstoken);
            this.startRefreshTokenTimer();
          }
          else {
            console.log(student.errorMessage);
          }
          return student;
        }),
        catchError(err => {
          return throwError(err);
        })
      );
  }

  // register(user: User) {
  //   const uservalReg = {
  //     "firstname": user.firstname,
  //     "lastname": user.lastname,
  //     "email": user.email,
  //     "password": user.password,
  //     "age": user.age,
  //     "gender": user.gender
  //   }
  //   return this.http.post(`${environment.apiUrl}/Register`, uservalReg)
  //     .pipe(
  //       map((Reguser: any) => {
  //         console.log(Reguser)
  //         if (!Reguser.error) {
  //           console.log(Reguser);
  //         } else {
  //           console.log(Reguser.errorMessage);
  //         }
  //         return Reguser;
  //       }),
  //       catchError(err => {
  //         return throwError(err);
  //       })
  //     );
  // }
  refreshToken() {
    let a = JSON.parse(sessionStorage.getItem("userinfo"))
    console.log(a)
    // if (a != null && a != "" && a != undefined) {
    let payload = {
      token: a?.refreshtoken
    }
    console.log(payload)
    return this.http.post<any>(`${environment.apiUrl}/login/refreshToken`, payload)
      // return this.http.post<any>(`${environment.apiUrl}/login/refreshToken`, payload, { withCredentials: true })
      .pipe(map((refreshUser: any) => {
        if (!refreshUser.error) {
          const refreshdetails = refreshUser.data;
          console.log(refreshUser)
          a.refreshtoken = refreshdetails?.refreshtoken;
          a.accesstoken = refreshdetails?.accesstoken;
          a.user.role = refreshdetails?.user?.role;
          a.user.user_guid = refreshdetails?.user?.user_guid;
          sessionStorage.setItem("userinfo", JSON.stringify(a))

          sessionStorage.setItem('currentUser', refreshdetails.accesstoken);
          sessionStorage.setItem('Role', refreshdetails.user.role);
          var event = document.createEvent("Event");
          event.initEvent("storage", true, true);
          window.dispatchEvent(event);
          console.log(refreshdetails.accesstoken)
          this.currentUserSubject.next(refreshdetails?.accesstoken);
          this.startRefreshTokenTimer();
        }
        else {
          console.log(refreshUser.errorMessage);
        }
        return refreshUser;
      }),
        catchError(err => {
          this.logout();
          // alert("ram")
          return throwError(err);
        }));
    // }else{
    //   this.stopRefreshTokenTimer();

    // }
  }

  private refreshTokenTimeout;

  private startRefreshTokenTimer() {
    console.log(this.currentUserValue)
    let Cuser = sessionStorage.getItem("currentUser")
    console.log(Cuser)
    // parse json object from base64 encoded jwt token
    // let a = JSON.parse(sessionStorage.getItem("userinfo"))
    // const jwtToken = JSON.parse(atob(a.accesstoken.split(".")[1]));
    // let a = JSON.parse(sessionStorage.getItem("userinfo"))
    const jwtToken = JSON.parse(atob(Cuser.split(".")[1]));
    const expires = new Date(jwtToken.exp * 1000);
    console.log(expires)

    // const jwtToken = JSON.parse(a.accesstoken.split(".")[1]);

    // set a timeout to refresh the token a minute before it expires
    // const expires = new Date(jwtToken.exp * 1000);
    const timeout = expires.getTime() - Date.now() - 60 * 1000;
    this.refreshTokenTimeout = setTimeout(
      () => this.refreshToken().subscribe(),
      timeout
    );
  }

  private stopRefreshTokenTimer() {
    clearTimeout(this.refreshTokenTimeout);
  }

  logout() {
    this.currentUserSubject.next(null);
    this.stopRefreshTokenTimer();
    sessionStorage.clear();
    $('body').addClass('noselect');
    // const localstor = JSON.parse(localStorage.getItem("dark-mode"));
    // localstor.darkMode = false; 
    // localStorage.setItem("dark-mode", JSON.stringify(localstor));

    // this.darkModeService.disable();

    this.router.navigate(['/login']);
  }

  emailVerification(payload) {
    return this.http.put(`${environment.apiUrl}/validatecode`, payload)
      .pipe(map((result: any) => {
        if (result) {
          return result;
        }
      }),
        catchError(err => {
          return throwError(err);
        })
      )
  }



  // register(registerdata: any) {
  //   console.log(registerdata)

  //   let data = {
  //     "firstname": registerdata.firstname,
  //     "lastname": registerdata.lastname,
  //     "email": registerdata.email,
  //     "age": registerdata.age,
  //     "password": registerdata.password,
  //     "gender": registerdata.gender,
  //     "qualification": registerdata.qualification,
  //     "experience": registerdata.workexperience,
  //   }
  //   return this.http.post(`${environment.apiUrl}/Register`, data)
  //     .pipe(
  //       map((user: any) => {
  //         console.log(user)
  //         if (user.success) {
  //           console.log(user);
  //         } else {
  //           console.log(user.errorMessage);
  //         }
  //         return user;
  //       }),
  //       catchError(err => {
  //         return throwError(err);
  //       })
  //     );

  // }


  // login(logindata: any) {
  //   console.log(logindata)

  //   let data = {
  //     "email": logindata.email,
  //     "password": logindata.password
  //   }

  //   return this.http.post(`${environment.apiUrl}/login`, data).pipe(map((loginRes: any) => {
  //     console.log(loginRes)
  //     if (!loginRes.Response.iserror) {

  //       sessionStorage.setItem('currentUser', loginRes.Response.token);
  //       sessionStorage.setItem('currentUserFirstName', loginRes.Response.user.firstname);
  //       sessionStorage.setItem('currentUserLastName', loginRes.Response.user.lastname);
  //       sessionStorage.setItem('Role', loginRes.Response.user.role);
  //       sessionStorage.setItem('Testtype', loginRes.Response.user.testtype);
  //       this.currentUserSubject.next(loginRes.Response.token);

  //     }
  //     else {
  //       console.log(loginRes.Response.errormessage);
  //     }
  //     return loginRes;
  //   }), catchError(err => {
  //     return throwError(err);
  //   })
  //   )

  // }


  // logOut() {
  //   // sessionStorage.clear();
  //   // sessionStorage.removeItem('currentUser');
  //   // sessionStorage.removeItem('currentUserName');
  //   // sessionStorage.removeItem('Role');
  //   // this.currentUserSubject.next(null);

  //   sessionStorage.clear();
  //   sessionStorage.removeItem('currentUser');
  //   sessionStorage.removeItem('currentUserName');
  //   sessionStorage.removeItem('Role');
  //   var event = document.createEvent("Event");
  //   event.initEvent("storage", true, true);
  //   window.dispatchEvent(event);
  //   this.currentUserSubject.next(null);
  // }

  // refreshToken() {
  //   return this.http.post<any>(`${environment.apiUrl}/users/refresh-token`, {}, { withCredentials: true })
  //       .pipe(map((user) => {
  //           this.userSubject.next(user);
  //           this.startRefreshTokenTimer();
  //           return user;
  //       }));
  // }

  // helper methods

  // private refreshTokenTimeout;

  // private startRefreshTokenTimer() {
  //     // parse json object from base64 encoded jwt token
  //     const jwtToken = JSON.parse(atob(this.currentUserValue.jwtToken.split('.')[1]));

  //     // set a timeout to refresh the token a minute before it expires
  //     const expires = new Date(jwtToken.exp * 1000);
  //     const timeout = expires.getTime() - Date.now() - (60 * 1000);
  //     this.refreshTokenTimeout = setTimeout(() => this.refreshToken().subscribe(), timeout);
  // }

  // private stopRefreshTokenTimer() {
  //     clearTimeout(this.refreshTokenTimeout);
  // }

}

