
import { Injectable } from '@angular/core';
import { HttpClient, HttpHeaders, HttpParams } from '@angular/common/http';
import { environment } from '../../environments/environment';
import { Observable, of, pipe, throwError } from 'rxjs';
import { map, switchMap, debounceTime, catchError } from 'rxjs/operators';

@Injectable({ providedIn: 'root' })
export class AdminService {

    constructor(private http: HttpClient) {
    }


    getproject() {
        return this.http.get(`${environment.apiUrl}LoadProject`).pipe(
            map((data: any) => {
                if (data) {
                    return data;
                }
            }),
            catchError((err) => {
                return throwError(err);
            })
        );
    }

    getmoleculekeyup(molecule) {
        return this.http.get(`${environment.apiUrl}GetExcipientName?excipientname=` + molecule).pipe(
            map((data: any) => {
                if (data) {
                    return data;
                }
            }),
            catchError((err) => {
                return throwError(err);
            })
        );
    }

    getExcipient(molecule) {
        return this.http.get(`${environment.apiUrl}GetExcipientDetails?excipientname=` + molecule).pipe(
            map((data: any) => {
                if (data) {
                    return data;
                }
            }),
            catchError((err) => {
                return throwError(err);
            })
        );
    }

    getjobids() {
        return this.http.get(`${environment.apiUrl}GetJobs `).pipe(
            map((data: any) => {
                if (data) {
                    return data;
                }
            }),
            catchError((err) => {
                return throwError(err);
            })
        );
    }

    getvisualtable(jobidsId) {
        return this.http.get(`${environment.apiUrl}GetJobDetails?jobid=` + jobidsId).pipe(
            map((data: any) => {
                if (data) {
                    return data;
                }
            }),
            catchError((err) => {
                return throwError(err);
            })
        );
    }

    getprototye() {
        return this.http.get(`${environment.apiUrl}getprototype`).pipe(
            map((data: any) => {
                if (data) {
                    return data;
                }
            }),
            catchError((err) => {
                return throwError(err);
            })
        );
    }

    createjob(paylod) {
        return this.http.post(`${environment.apiUrl}CreateJob`, paylod).pipe(
            map((data: any) => {
                if (data) {
                    return data;
                }
            }),
            catchError((err) => {
                return throwError(err);
            })
        );
    }

    createjobmulti(paylod) {
        return this.http.post(`${environment.apiUrl}CreateJobMultiple`, paylod).pipe(
            map((data: any) => {
                if (data) {
                    return data;
                }
            }),
            catchError((err) => {
                return throwError(err);
            })
        );
    }

    createjobwithAPI(paylod) {
        return this.http.post(`${environment.apiUrl}CreateJobApiProperties`, paylod).pipe(
            map((data: any) => {
                if (data) {
                    return data;
                }
            }),
            catchError((err) => {
                return throwError(err);
            })
        );
    }

    savemolecules(paylod) {
        return this.http.post(`${environment.apiUrl}AddExcipicient`, paylod).pipe(
            map((data: any) => {
                if (data) {
                    return data;
                }
            }),
            catchError((err) => {
                return throwError(err);
            })
        );
    }

    // get joblist
    getjoblist(pageno, pagesize) {
        return this.http.get(`${environment.apiUrl}GetJobStatus?offset=` + pageno + `&limit=` + pagesize + `&Iscountrequired=true`).pipe(
            map((data: any) => {
                if (data) {
                    return data;
                }
            }),
            catchError((err) => {
                return throwError(err);
            })
        );
    }

    // get projectreportlist
    getprojectreport(pageno, pagesize) {
        return this.http.get(`${environment.apiUrl}GetProjectreport?offset=` + pageno + `&limit=` + pagesize + `&Iscountrequired=true`).pipe(
            map((data: any) => {
                if (data) {
                    return data;
                }
            }),
            catchError((err) => {
                return throwError(err);
            })
        );
    }

    // create userlistlist
    createuser(paylod) {
        return this.http.post(`${environment.apiUrl}CreateUser`, paylod).pipe(
            map((data: any) => {
                if (data) {
                    return data;
                }
            }),
            catchError((err) => {
                return throwError(err);
            })
        );
    }

    // create project
    createproject(paylod) {
        return this.http.post(`${environment.apiUrl}CreateProject`, paylod).pipe(
            map((data: any) => {
                if (data) {
                    return data;
                }
            }),
            catchError((err) => {
                return throwError(err);
            })
        );
    }
    // get status dropdown
    getstatus() {
        return this.http.get(`${environment.apiUrl}getprojectstatus `).pipe(
            map((data: any) => {
                if (data) {
                    return data;
                }
            }),
            catchError((err) => {
                return throwError(err);
            })
        );
    }

    // edit project by Id
    getProjectById(Id) {
        return this.http.get(`${environment.apiUrl}GetProjectbyid?project_id=` + Id)
            .pipe(map((data: any) => {
                if (data) {
                    return data;
                }
            }),
                catchError((err) => {
                    return throwError(err);
                })
            );
    }
    // update project by Id
    updateProjectById(payload, Id) {
        return this.http.put(`${environment.apiUrl}UpdateProject?project_id=` + Id, payload)
            .pipe(map((data: any) => {
                if (data) {
                    return data;
                }
            }),
                catchError((err) => {
                    return throwError(err);
                })
            );
    }
    // get roletype dropdown
    getroletype() {
        return this.http.get(`${environment.apiUrl}getroletype`).pipe(
            map((data: any) => {
                if (data) {
                    return data;
                }
            }),
            catchError((err) => {
                return throwError(err);
            })
        );
    }
    // get projectlist
    getprojectlist(pageno, pagesize) {
        return this.http.get(`${environment.apiUrl}LoadProjectList?offset=` + pageno + `&limit=` + pagesize + `&Iscountrequired=true`).pipe(
            map((data: any) => {
                if (data) {
                    return data;
                }
            }),
            catchError((err) => {
                return throwError(err);
            })
        );
    }

    getassignuserlist(keyvalue) {
        return this.http.get(`${environment.apiUrl}Userlist?search=` + keyvalue).pipe(
            map((data: any) => {
                if (data) {
                    return data;
                }
            }),
            catchError((err) => {
                return throwError(err);
            })
        );
    }


    // get userlist
    getuserlist(pageno, pagesize) {
        return this.http.get(`${environment.apiUrl}GetUserList?offset=` + pageno + `&limit=` + pagesize + `&Iscountrequired=true`).pipe(
            map((data: any) => {
                if (data) {
                    return data;
                }
            }),
            catchError((err) => {
                return throwError(err);
            })
        );
    }
    // edit user by Id
    getUserById(Id) {
        return this.http.get(`${environment.apiUrl}getUserDetails?userid=` + Id)
            .pipe(map((data: any) => {
                if (data) {
                    return data;
                }
            }),
                catchError((err) => {
                    return throwError(err);
                })
            );
    }
    // update user by Id
    updateUserById(payload) {
        return this.http.put(`${environment.apiUrl}UpdateUser`, payload)
            .pipe(map((data: any) => {
                if (data) {
                    return data;
                }
            }),
                catchError((err) => {
                    return throwError(err);
                })
            );
    }
    // user status
    changeUserState(payload) {
        return this.http
            .put(
                `${environment.apiUrl}UpdateUserStatus`, payload
            )
            .pipe(
                map((data: any) => {
                    if (data) {
                        return data;
                    }
                }),
                catchError((err) => {
                    return throwError(err);
                })
            );
    }

    //   downloadcsv visualization page
    downloadcsv(Id) {
        return this.http.get(`${environment.apiUrl}downloadcsv?jobid=` + Id, { responseType: 'blob' })
            .pipe(map((data: any) => {
                if (data) {
                    return data;
                }
            }),
                catchError((err) => {
                    return throwError(err);
                })
            );
    }


    //user  searchfilter with pagination
    userlistfilter(filterstring, pageno, pageSize) {
        return this.http
            .get(
                `${environment.apiUrl}SearchUser?search=` +
                filterstring +
                `&offset=` +
                pageno +
                `&limit=` +
                pageSize +
                `&Iscountrequired=true`
            )
            .pipe(
                map((data: any) => {
                    if (data) {
                        return data;
                    }
                }),
                catchError((err) => {
                    return throwError(err);
                })
            );
    }

    //project searchfilter with pagination
    projectlistfilter(filterstring, pageno, pageSize) {
        return this.http
            .get(
                `${environment.apiUrl}SearchProjectList?search=` +
                filterstring +
                `&offset=` +
                pageno +
                `&limit=` +
                pageSize +
                `&Iscountrequired=true`
            )
            .pipe(
                map((data: any) => {
                    if (data) {
                        return data;
                    }
                }),
                catchError((err) => {
                    return throwError(err);
                })
            );
    }

    assignuser(payload) {
        return this.http.post(`${environment.apiUrl}AssignUser`, payload)
            .pipe(map((data: any) => {
                if (data) {
                    return data;
                }
            }),
                catchError((err) => {
                    return throwError(err);
                })
            );
    }


    unassignuser(payload) {
        return this.http.put(`${environment.apiUrl}UnAssignUser`, payload)
            .pipe(map((data: any) => {
                if (data) {
                    return data;
                }
            }),
                catchError((err) => {
                    return throwError(err);
                })
            );
    }
    // get projecdashboard
    getprojectdashboard() {
        return this.http.get(`${environment.apiUrl}Dashboard`).pipe(
            map((data: any) => {
                if (data) {
                    return data;
                }
            }),
            catchError((err) => {
                return throwError(err);
            })
        );
    }

    // get projects detail page
    getuserprojectdetail(pid, pagesize, pageno) {
        return this.http.get(`${environment.apiUrl}Getdashboradprojectdetails?Project_id=` + pid + `&offset=` + pagesize + `&limit=` + pageno + `&Iscountrequired=true`).pipe(
            map((data: any) => {
                if (data) {
                    return data;
                }
            }),
            catchError((err) => {
                return throwError(err);
            })
        );
    }
    // get projects detail page
    getjobprojectdetail(pid, pagesize, pageno) {
        return this.http.get(`${environment.apiUrl}Getdashboradjobdetails?Project_id=` + pid + `&offset=` + pagesize + `&limit=` + pageno + `&Iscountrequired=true`).pipe(
            map((data: any) => {
                if (data) {
                    return data;
                }
            }),
            catchError((err) => {
                return throwError(err);
            })
        );
    }


    // update user password
    updateUserPassword(payload) {
        return this.http.put(`${environment.apiUrl}UpdateUserPassword`, payload)
            .pipe(map((data: any) => {
                if (data) {
                    return data;
                }
            }),
                catchError((err) => {
                    return throwError(err);
                })
            );
    }

    downloadpdf(Id) {
        return this.http.get(`${environment.apiUrl}downloadpdf?jobid=` + Id, { responseType: 'blob' })
            .pipe(map((data: any) => {
                if (data) {
                    return data;
                }
            }),
                catchError((err) => {
                    return throwError(err);
                })
            );
    }


    getmultijob(Id) {
        return this.http.get(`${environment.apiUrl}GetJobDetailsByMultipleJob?jobid=` + Id)
            .pipe(map((data: any) => {
                if (data) {
                    return data;
                }
            }),
                catchError((err) => {
                    return throwError(err);
                })
            );
    }


    multidownloadcsv(Id) {
        return this.http.get(`${environment.apiUrl}downloadmultiplejobcsv?jobid=` + Id, { responseType: 'blob' })
            .pipe(map((data: any) => {
                if (data) {
                    return data;
                }
            }),
                catchError((err) => {
                    return throwError(err);
                })
            );
    }

    multidownloadpdf(Id) {
        return this.http.get(`${environment.apiUrl}downloadpdf?jobid=` + Id, { responseType: 'blob' })
            .pipe(map((data: any) => {
                if (data) {
                    return data;
                }
            }),
                catchError((err) => {
                    return throwError(err);
                })
            );
    }

    excipientlistcsv() {
        return this.http.get(`${environment.apiUrl}excipientdownloadcsv`, { responseType: 'blob' })
            .pipe(map((data: any) => {
                if (data) {
                    return data;
                }
            }),
                catchError((err) => {
                    return throwError(err);
                })
            );
    }


    // get joblist
    getexcipientlist(pageno, pagesize) {
        return this.http.get(`${environment.apiUrl}GetExcipientList?offset=` + pageno + `&limit=` + pagesize + `&Iscountrequired=true`).pipe(
            map((data: any) => {
                if (data) {
                    return data;
                }
            }),
            catchError((err) => {
                return throwError(err);
            })
        );
    }




    getchart(jobidsId) {
        return this.http.get(`${environment.apiUrl}GetMultipleJobBarchart?jobid=` + jobidsId).pipe(
            map((data: any) => {
                if (data) {
                    return data;
                }
            }),
            catchError((err) => {
                return throwError(err);
            })
        );
    }



    // get Search excipientlist
    Searchexcipientlist(pageno, pagesize, searchstring) {
        // SearchExcipientList?offset=0&limit=10&Iscountrequired=true&excipientname=glycerol  =>Get API
        return this.http.get(`${environment.apiUrl}SearchExcipientList?offset=` + pageno + `&limit=` + pagesize + `&Iscountrequired=true&excipientname=` + searchstring).pipe(
            map((data: any) => {
                if (data) {
                    return data;
                }
            }),
            catchError((err) => {
                return throwError(err);
            })
        );
    }



    // get Search joblist
    Searchjoblist(pageno, pagesize, searchstring) {
        return this.http.get(`${environment.apiUrl}GetSearchJobStatus?offset=` + pageno + `&limit=` + pagesize + `&Iscountrequired=true&jobname=` + searchstring).pipe(
            map((data: any) => {
                if (data) {
                    return data;
                }
            }),
            catchError((err) => {
                return throwError(err);
            })
        );
    }



    // csv upload
    // csvupload(payload) {

    //     return this.http.post(`${environment.apiUrl}UploadExcipientList`, payload)
    //         .pipe(
    //             map((data: any) => {
    //                 if (data) {
    //                     return data;
    //                 }
    //             }),
    //             catchError((err) => {
    //                 return throwError(err);
    //             })
    //         );
    // }

    csvupload(payload) {

        return this.http.post(`${environment.apiUrl}UploadMultipleExcipientList`, payload)
            .pipe(
                map((data: any) => {
                    if (data) {
                        return data;
                    }
                }),
                catchError((err) => {
                    return throwError(err);
                })
            );
    }


    sendocfile(jobidsId) {
        return this.http.post(`${environment.apiUrl}CreateUploadExcipient`, jobidsId).pipe(
            map((data: any) => {
                if (data) {
                    return data;
                }
            }),
            catchError((err) => {
                return throwError(err);
            })
        );
    }

    deleteexcipient(Id) {
        console.log(Id);
        
        return this.http.put(`${environment.apiUrl}DeleteExcipient`, Id).pipe(
            map((data: any) => {
                if (data) {
                    return data;
                }
            }),
            catchError((err) => {
                return throwError(err);
            })
        );
    }
}