export class User {
    email: string;
    password: string;
    firstname: string;
    lastname: string;
    age: Number;
    gender: string;   
    role:string 
}
