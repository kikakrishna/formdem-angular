export class Password {
    oldpassword: any;
    newpassword: any;
}